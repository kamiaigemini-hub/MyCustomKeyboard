package com.example.customkeyboard.text

import android.view.inputmethod.InputConnection

/**
 * 한글 자음/모음을 실시간으로 완성형 글자로 합쳐주는 엔진.
 * 예: ㄱ -> ㄱ+ㅏ="가" -> 가+ㄴ="간" -> 간+ㅏ="가"+"나"(간의 ㄴ이 다음 글자의 초성이 됨)
 *
 * getIC: 현재 입력창(InputConnection)을 가져오는 함수. IME에서 넘겨줍니다.
 */
class HangulComposer(private val getIC: () -> InputConnection?) {

    companion object {
        const val CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
        const val JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
        const val JONG = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"

        val JUNG_COMBINE = mapOf(
            "ㅗㅏ" to "ㅘ", "ㅗㅐ" to "ㅙ", "ㅗㅣ" to "ㅚ",
            "ㅜㅓ" to "ㅝ", "ㅜㅔ" to "ㅞ", "ㅜㅣ" to "ㅟ",
            "ㅡㅣ" to "ㅢ"
        )
        val JUNG_DECOMPOSE = mapOf(
            "ㅘ" to Pair('ㅗ', 'ㅏ'), "ㅙ" to Pair('ㅗ', 'ㅐ'), "ㅚ" to Pair('ㅗ', 'ㅣ'),
            "ㅝ" to Pair('ㅜ', 'ㅓ'), "ㅞ" to Pair('ㅜ', 'ㅔ'), "ㅟ" to Pair('ㅜ', 'ㅣ'),
            "ㅢ" to Pair('ㅡ', 'ㅣ')
        )
        val JONG_COMBINE = mapOf(
            "ㄱㅅ" to "ㄳ", "ㄴㅈ" to "ㄵ", "ㄴㅎ" to "ㄶ",
            "ㄹㄱ" to "ㄺ", "ㄹㅁ" to "ㄻ", "ㄹㅂ" to "ㄼ", "ㄹㅅ" to "ㄽ",
            "ㄹㅌ" to "ㄾ", "ㄹㅍ" to "ㄿ", "ㄹㅎ" to "ㅀ", "ㅂㅅ" to "ㅄ"
        )
        val JONG_DECOMPOSE = mapOf(
            "ㄳ" to Pair('ㄱ', 'ㅅ'), "ㄵ" to Pair('ㄴ', 'ㅈ'), "ㄶ" to Pair('ㄴ', 'ㅎ'),
            "ㄺ" to Pair('ㄹ', 'ㄱ'), "ㄻ" to Pair('ㄹ', 'ㅁ'), "ㄼ" to Pair('ㄹ', 'ㅂ'),
            "ㄽ" to Pair('ㄹ', 'ㅅ'), "ㄾ" to Pair('ㄹ', 'ㅌ'), "ㄿ" to Pair('ㄹ', 'ㅍ'),
            "ㅀ" to Pair('ㄹ', 'ㅎ'), "ㅄ" to Pair('ㅂ', 'ㅅ')
        )
    }

    private var cho: Char? = null
    private var jung: Char? = null
    private var jong: Char? = null

    /** 자음이나 모음 한 글자를 입력받아 조합을 진행합니다. */
    fun inputJamo(ch: Char) {
        val isCho = CHO.contains(ch)
        val isJung = JUNG.contains(ch)
        if (!isCho && !isJung) return

        if (isJung) {
            when {
                jong != null -> {
                    // 받침이 있는 상태에서 모음이 오면, 받침을 다음 글자의 초성으로 넘겨줍니다.
                    val decomposed = JONG_DECOMPOSE[jong.toString()]
                    val newCho: Char
                    if (decomposed != null) {
                        jong = decomposed.first
                        newCho = decomposed.second
                    } else {
                        newCho = jong!!
                        jong = null
                    }
                    commitCurrent()
                    cho = newCho
                    jung = ch
                }
                jung != null -> {
                    val combined = JUNG_COMBINE["${jung}$ch"]
                    if (combined != null) {
                        jung = combined[0]
                    } else {
                        commitCurrent()
                        jung = ch
                    }
                }
                else -> {
                    jung = ch
                }
            }
        } else {
            when {
                jong != null -> {
                    val combined = JONG_COMBINE["${jong}$ch"]
                    if (combined != null) {
                        jong = combined[0]
                    } else {
                        commitCurrent()
                        cho = ch
                    }
                }
                jung != null -> {
                    if (cho != null) {
                        jong = ch
                    } else {
                        commitCurrent()
                        cho = ch
                    }
                }
                cho != null -> {
                    commitCurrent()
                    cho = ch
                }
                else -> {
                    cho = ch
                }
            }
        }
        updateComposing()
    }

    /** 백스페이스 처리. 조합 중인 글자가 있으면 한 조각씩 지우고 true를 반환합니다. */
    fun backspace(): Boolean {
        if (jong != null) {
            jong = null
            updateComposing()
            return true
        }
        if (jung != null) {
            val base = JUNG_DECOMPOSE[jung.toString()]
            jung = base?.first
            updateComposing()
            return true
        }
        if (cho != null) {
            cho = null
            updateComposing()
            return true
        }
        return false
    }

    /** 조합 중인 글자를 확정해서 입력창에 보냅니다. (스페이스/엔터/다른 언어 전환 등에서 호출) */
    fun commit() {
        commitCurrent()
    }

    private fun commitCurrent() {
        val ic = getIC() ?: return
        val text = currentText()
        if (text.isNotEmpty()) {
            ic.commitText(text, 1)
        } else {
            ic.finishComposingText()
        }
        cho = null
        jung = null
        jong = null
    }

    private fun updateComposing() {
        val ic = getIC() ?: return
        ic.setComposingText(currentText(), 1)
    }

    private fun currentText(): String {
        if (cho == null && jung == null) return ""
        if (cho != null && jung != null) {
            val choIdx = CHO.indexOf(cho!!)
            val jungIdx = JUNG.indexOf(jung!!)
            val jongIdx = if (jong == null) 0 else JONG.indexOf(jong!!)
            val code = 0xAC00 + (choIdx * 21 + jungIdx) * 28 + jongIdx
            return code.toChar().toString()
        }
        return (cho ?: jung).toString()
    }
}
