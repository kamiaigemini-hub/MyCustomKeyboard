package com.example.customkeyboard.model

/**
 * 키의 종류. NORMAL은 그냥 글자를 입력하는 키이고,
 * 나머지는 특수 동작을 하는 키입니다.
 */
enum class KeyType { NORMAL, SHIFT, BACKSPACE, ENTER, SPACE, SYMBOLS_TOGGLE, LANG_SWITCH, CHEONJIIN_CONS, CHEONJIIN_STROKE, DIACRITIC, CLIPBOARD_TOGGLE, CURSOR_MOVE }

/**
 * 키 하나를 표현하는 데이터.
 * label: 화면에 보이는 글자이자, NORMAL 타입일 때 실제로 입력되는 문자.
 * weight: 다른 키에 비해 얼마나 넓게 그릴지 (스페이스바처럼 넓은 키는 weight를 크게).
 * popup: 길게 눌렀을 때 나오는 추가 글자들 (예: a -> á, à, â).
 * mark: DIACRITIC 타입일 때 실제로 앞 글자에 합쳐질 결합 문자 (예: 성조 표시).
 */
data class KeyDef(
    var label: String,
    var type: KeyType = KeyType.NORMAL,
    var weight: Float = 1f,
    var popup: List<String> = emptyList(),
    var mark: String = ""
)

/**
 * 키보드 전체 레이아웃. 행(row)의 리스트로 구성됩니다.
 */
data class KeyboardLayout(
    var name: String,
    var rows: MutableList<MutableList<KeyDef>>
)
