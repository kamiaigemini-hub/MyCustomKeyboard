package com.example.customkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "커스텀 키보드"
            textSize = 22f
            setPadding(0, 0, 0, 48)
        }

        val desc = TextView(this).apply {
            text = "1) 키보드를 활성화하고\n2) 아무 입력창에서 이 키보드로 전환한 뒤\n3) 레이아웃을 자유롭게 편집해보세요."
            textSize = 15f
            setPadding(0, 0, 0, 64)
        }

        val enableBtn = Button(this).apply {
            text = "1. 키보드 활성화 (설정 열기)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val switchBtn = Button(this).apply {
            text = "2. 키보드 전환 (선택창 열기)"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        val settingsBtn = Button(this).apply {
            text = "3. 레이아웃 커스터마이징"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }

        val languageBtn = Button(this).apply {
            text = "4. 언어 관리 (설치/삭제)"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, LanguageActivity::class.java))
            }
        }

        val themeBtn = Button(this).apply {
            text = "5. 키보드 꾸미기 (색/배경/크기)"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ThemeActivity::class.java))
            }
        }

        root.addView(title)
        root.addView(desc)
        root.addView(enableBtn)
        root.addView(switchBtn)
        root.addView(settingsBtn)
        root.addView(languageBtn)
        root.addView(themeBtn)
        setContentView(root)
    }
}
