package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray

/**
 * 최근에 복사한 글자들을 기억해두는 클립보드 기록.
 */
object ClipboardStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_HISTORY = "clipboard_history"
    private const val MAX_ITEMS = 15

    fun getHistory(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addEntry(context: Context, text: String) {
        if (text.isBlank()) return
        val current = getHistory(context).toMutableList()
        current.remove(text)
        current.add(0, text)
        while (current.size > MAX_ITEMS) current.removeAt(current.size - 1)
        save(context, current)
    }

    fun reorder(context: Context, newOrder: List<String>) {
        save(context, newOrder)
    }

    fun removeEntry(context: Context, text: String) {
        val current = getHistory(context).toMutableList()
        current.remove(text)
        save(context, current)
    }

    fun setHistory(context: Context, items: List<String>) {
        save(context, items)
    }

    fun clear(context: Context) {
        save(context, emptyList())
    }

    private fun save(context: Context, items: List<String>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }
}
