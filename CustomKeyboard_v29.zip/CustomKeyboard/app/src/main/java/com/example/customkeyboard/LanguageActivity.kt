package com.example.customkeyboard

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.customkeyboard.model.LanguageStore

class LanguageActivity : AppCompatActivity() {

    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 32)
        }

        val info = TextView(this).apply {
            text = "설치할 언어를 체크하세요. 최소 1개는 항상 켜져 있어야 해요.\n\n" +
                "베트남어, 아랍어 같은 언어는 직접 추가해서 만들 수 있어요! " +
                "'+ 새 언어 추가'를 누르면 영어 자판을 복사한 빈 틀이 생기고, " +
                "'레이아웃 커스터마이징'에서 그 언어의 글자로 하나씩 바꾸면 돼요."
            setPadding(0, 0, 0, 24)
        }
        root.addView(info)

        val addBtn = Button(this).apply {
            text = "+ 새 언어 추가"
            setOnClickListener { showAddLanguageDialog() }
        }
        root.addView(addBtn)

        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 24, 0, 0)
        }
        root.addView(listContainer)
        renderList()

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showAddLanguageDialog() {
        val input = EditText(this).apply { hint = "언어 이름 (예: 베트남어, 아랍어)" }
        AlertDialog.Builder(this)
            .setTitle("새 언어 추가")
            .setView(input)
            .setPositiveButton("추가") { _, _ ->
                val name = input.text.toString()
                if (name.isNotEmpty()) {
                    val newLang = LanguageStore.addCustomLanguage(this, name)
                    Toast.makeText(this, "$name 추가됨! 이제 글자를 편집해보세요.", Toast.LENGTH_SHORT).show()
                    renderList()
                    val intent = Intent(this, SettingsActivity::class.java)
                    intent.putExtra(SettingsActivity.EXTRA_LANG_CODE, newLang.code)
                    startActivity(intent)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun renderList() {
        listContainer.removeAllViews()
        val installedCodes = LanguageStore.installedCodes(this)
        val customCodes = LanguageStore.customLanguages(this).map { it.code }.toSet()

        LanguageStore.allLanguages(this).forEach { lang ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 12, 0, 12)
            }
            val check = CheckBox(this).apply {
                text = lang.displayName
                isChecked = installedCodes.contains(lang.code)
                setOnClickListener {
                    LanguageStore.setInstalled(this@LanguageActivity, lang.code, isChecked)
                    val stillInstalled = LanguageStore.installedCodes(this@LanguageActivity).contains(lang.code)
                    val message = if (stillInstalled) "${lang.displayName} 설치됨" else "${lang.displayName} 꺼짐"
                    Toast.makeText(this@LanguageActivity, message, Toast.LENGTH_SHORT).show()
                    renderList()
                }
            }
            row.addView(check)

            val editBtn = Button(this).apply {
                text = "편집"
                setOnClickListener {
                    val intent = Intent(this@LanguageActivity, SettingsActivity::class.java)
                    intent.putExtra(SettingsActivity.EXTRA_LANG_CODE, lang.code)
                    startActivity(intent)
                }
            }
            row.addView(editBtn)

            if (lang.code in customCodes) {
                val deleteBtn = Button(this).apply {
                    text = "완전삭제"
                    setOnClickListener {
                        LanguageStore.removeCustomLanguage(this@LanguageActivity, lang.code)
                        Toast.makeText(this@LanguageActivity, "${lang.displayName} 삭제됨", Toast.LENGTH_SHORT).show()
                        renderList()
                    }
                }
                row.addView(deleteBtn)
            }

            listContainer.addView(row)
        }
    }
}
