package com.example.customkeyboard.model

enum class BackgroundType { SOLID, GRADIENT, IMAGE }

enum class GradientDirection { TOP_TO_BOTTOM, LEFT_TO_RIGHT, DIAGONAL, RADIAL }

/**
 * 키보드의 배경/버튼 색/크기/테두리를 담는 테마 설정.
 * 색상은 안드로이드 Color.parseColor 형식의 Int로 저장합니다.
 */
data class KeyboardTheme(
    var backgroundType: BackgroundType = BackgroundType.SOLID,
    var backgroundColor: Int = 0xFFEDEFF2.toInt(),
    var gradientColors: List<Int> = listOf(0xFFEDEFF2.toInt(), 0xFFC9D6E3.toInt()),
    var gradientDirection: GradientDirection = GradientDirection.TOP_TO_BOTTOM,
    var backgroundImageUri: String? = null,
    var keyColor: Int = 0xFFFFFFFF.toInt(),
    var specialKeyColor: Int = 0xFFD8DCE0.toInt(),
    var textColor: Int = 0xFF1A1A1A.toInt(),
    var keySizeScale: Float = 1f,
    var keyGapScale: Float = 1f,
    var borderEnabled: Boolean = false,
    var borderType: BackgroundType = BackgroundType.SOLID,
    var borderColor: Int = 0xFFB9C2CC.toInt(),
    var borderGradientColors: List<Int> = listOf(0xFF4C7CF0.toInt(), 0xFFB197FC.toInt()),
    var borderGradientDirection: GradientDirection = GradientDirection.LEFT_TO_RIGHT,
    var borderWidth: Float = 8f,
    var keyBorderEnabled: Boolean = false,
    var keyBorderType: BackgroundType = BackgroundType.SOLID,
    var keyBorderColor: Int = 0xFFB9C2CC.toInt(),
    var keyBorderGradientColors: List<Int> = listOf(0xFF4C7CF0.toInt(), 0xFFB197FC.toInt()),
    var keyBorderGradientDirection: GradientDirection = GradientDirection.LEFT_TO_RIGHT,
    var keyBorderWidth: Float = 3f,
    var fontFamily: String = "DEFAULT", // DEFAULT, SERIF, SANS_SERIF, MONOSPACE, CUSTOM
    var customFontUri: String? = null
)
