package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 언어별 키보드 레이아웃을 저장/불러오기.
 * 언어 코드(예: "ko", "en")마다 따로 저장됩니다.
 */
object LayoutStore {

    private const val PREFS = "keyboard_prefs"

    fun loadLayout(context: Context, code: String): KeyboardLayout {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(keyFor(code), null)
        return if (json != null) fromJson(json) else defaultLayout(code)
    }

    fun saveLayout(context: Context, code: String, layout: KeyboardLayout) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(keyFor(code), toJson(layout)).apply()
    }

    fun resetLayout(context: Context, code: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().remove(keyFor(code)).apply()
    }

    private fun keyFor(code: String) = "layout_$code"

    fun defaultLayout(code: String): KeyboardLayout = when (code) {
        "ko" -> defaultKoreanLayout()
        "ko_cheonjiin" -> defaultCheonjiinLayout()
        "vi" -> defaultVietnameseLayout()
        "symbols" -> defaultSymbolsLayout()
        "zalgo" -> defaultZalgoLayout()
        else -> defaultLettersLayout()
    }

    fun defaultSymbolsLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            row("@", "#", "$", "%", "&", "*", "-", "+", "(", ")"),
            mutableListOf(
                KeyDef("=\\<"),
                KeyDef("!"),
                KeyDef("\""),
                KeyDef("'"),
                KeyDef(":"),
                KeyDef(";"),
                KeyDef("/"),
                KeyDef("?"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            mutableListOf(
                KeyDef("◀", KeyType.CURSOR_MOVE, mark = "LEFT"),
                KeyDef("▲", KeyType.CURSOR_MOVE, mark = "UP"),
                KeyDef("▼", KeyType.CURSOR_MOVE, mark = "DOWN"),
                KeyDef("▶", KeyType.CURSOR_MOVE, mark = "RIGHT")
            ),
            bottomRow("ABC")
        )
        return KeyboardLayout("symbols", rows)
    }

    fun defaultLettersLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("q"), KeyDef("w"),
                KeyDef("e", popup = listOf("é", "è", "ê", "ë")),
                KeyDef("r"), KeyDef("t"), KeyDef("y"),
                KeyDef("u", popup = listOf("ú", "ù", "ü")),
                KeyDef("i", popup = listOf("í", "ì", "î")),
                KeyDef("o", popup = listOf("ó", "ò", "ö")),
                KeyDef("p")
            ),
            mutableListOf(
                KeyDef("a", popup = listOf("á", "à", "â", "ä")),
                KeyDef("s", popup = listOf("ß")),
                KeyDef("d"), KeyDef("f"), KeyDef("g"), KeyDef("h"),
                KeyDef("j"), KeyDef("k"), KeyDef("l")
            ),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("z"), KeyDef("x"),
                KeyDef("c", popup = listOf("ç")),
                KeyDef("v"), KeyDef("b"),
                KeyDef("n", popup = listOf("ñ")),
                KeyDef("m"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("en", rows)
    }

    fun defaultKoreanLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("ㅂ", popup = listOf("ㅃ")),
                KeyDef("ㅈ", popup = listOf("ㅉ")),
                KeyDef("ㄷ", popup = listOf("ㄸ")),
                KeyDef("ㄱ", popup = listOf("ㄲ")),
                KeyDef("ㅅ", popup = listOf("ㅆ")),
                KeyDef("ㅛ"), KeyDef("ㅕ"), KeyDef("ㅑ"),
                KeyDef("ㅐ", popup = listOf("ㅒ")),
                KeyDef("ㅔ", popup = listOf("ㅖ"))
            ),
            row("ㅁ", "ㄴ", "ㅇ", "ㄹ", "ㅎ", "ㅗ", "ㅓ", "ㅏ", "ㅣ"),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("ㅋ"), KeyDef("ㅌ"), KeyDef("ㅊ"), KeyDef("ㅍ"),
                KeyDef("ㅠ"), KeyDef("ㅜ"), KeyDef("ㅡ"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("ko", rows)
    }

    fun defaultCheonjiinLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("ㄱㅋㄲ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄱ", "ㅋ", "ㄲ")),
                KeyDef("ㄴㄹ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄴ", "ㄹ")),
                KeyDef("ㄷㅌㄸ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄷ", "ㅌ", "ㄸ")),
                KeyDef("ㅁㅇ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅁ", "ㅇ"))
            ),
            mutableListOf(
                KeyDef("ㅂㅍㅃ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅂ", "ㅍ", "ㅃ")),
                KeyDef("ㅅㅎㅆ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅅ", "ㅎ", "ㅆ")),
                KeyDef("ㅈㅊㅉ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅈ", "ㅊ", "ㅉ")),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            mutableListOf(
                KeyDef("ㅣ", KeyType.CHEONJIIN_STROKE),
                KeyDef("ㆍ", KeyType.CHEONJIIN_STROKE),
                KeyDef("ㅡ", KeyType.CHEONJIIN_STROKE)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("ko_cheonjiin", rows)
    }

    fun defaultVietnameseLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            row("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            row("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("z"), KeyDef("x"), KeyDef("c"), KeyDef("v"), KeyDef("b"), KeyDef("n"), KeyDef("m"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            mutableListOf(
                KeyDef("MŨ", KeyType.DIACRITIC, mark = "\u0302"),   // â ê ô
                KeyDef("TRĂNG", KeyType.DIACRITIC, mark = "\u0306"), // ă
                KeyDef("MÓC", KeyType.DIACRITIC, mark = "\u031B"),   // ơ ư
                KeyDef("Đ", KeyType.DIACRITIC, mark = "STROKE"),     // d -> đ
                KeyDef("SẮC", KeyType.DIACRITIC, mark = "\u0301"),
                KeyDef("HUYỀN", KeyType.DIACRITIC, mark = "\u0300"),
                KeyDef("HỎI", KeyType.DIACRITIC, mark = "\u0309"),
                KeyDef("NGÃ", KeyType.DIACRITIC, mark = "\u0303"),
                KeyDef("NẶNG", KeyType.DIACRITIC, mark = "\u0323")
            ),
            bottomRow("123")
        )
        return KeyboardLayout("vi", rows)
    }

    // 유니코드 "결합 문자(Combining Marks)" 관련 블록 전체를 모았어요.
    // U+0300~U+036F (Combining Diacritical Marks, 112개)
    // U+1DC0~U+1DFF (Combining Diacritical Marks Supplement, 64개)
    // U+20D0~U+20FF (Combining Diacritical Marks for Symbols, 48개)
    // U+FE20~U+FE2F (Combining Half Marks, 16개)
    // 다 합쳐서 240개, 진짜 Zalgo 텍스트에 쓰이는 유니코드 범위예요.
    // 앱이 시작될 때 딱 한 번만 배열로 만들어두고, 이후에는 인덱스로만 꺼내 씁니다 (매번 새로 안 만듦).
    private val zalgoMarks: CharArray = (
        (0x0300..0x036F) +
            (0x1DC0..0x1DFF) +
            (0x20D0..0x20FF) +
            (0xFE20..0xFE2F)
        ).map { it.toChar() }.toCharArray()

    private val zalgoLetters: CharArray = ('a'..'z').toList().toCharArray()

    fun defaultZalgoLayout(): KeyboardLayout {
        val letterCount = zalgoLetters.size
        // 240개 결합 문자를 26개 글자에 골고루 나눠서, 어떤 글자를 길게 눌러도 다른 조합이 나오게 합니다.
        // (전부 다 겹치지 않게 나누기 때문에, 26개 글자를 다 훑어보면 240개를 전부 만날 수 있어요.)
        val popupBuckets = Array(letterCount) { mutableListOf<String>() }
        for (i in zalgoMarks.indices) {
            popupBuckets[i % letterCount].add(zalgoMarks[i].toString())
        }

        var idx = 0
        val letterRow1 = mutableListOf<KeyDef>()
        repeat(9) { letterRow1.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        val letterRow2 = mutableListOf<KeyDef>()
        repeat(9) { letterRow2.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        val letterRow3 = mutableListOf<KeyDef>()
        repeat(8) { letterRow3.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        letterRow3.add(KeyDef("⌫", KeyType.BACKSPACE, 1.5f))

        // 자주 쓰이는 결합 문자는 길게 누르지 않고 바로 탭할 수 있게 두 줄 더 넣어둡니다.
        val quickRow1 = (0 until 11).map { KeyDef(zalgoMarks[it].toString()) }.toMutableList()
        val quickRow2 = (11 until 22).map { KeyDef(zalgoMarks[it].toString()) }.toMutableList()

        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            letterRow1,
            letterRow2,
            letterRow3,
            quickRow1,
            quickRow2,
            bottomRow("123")
        )
        return KeyboardLayout("zalgo", rows)
    }

    private fun bottomRow(symbolsToggleLabel: String): MutableList<KeyDef> =
        mutableListOf(
            KeyDef(symbolsToggleLabel, KeyType.SYMBOLS_TOGGLE, 1.2f),
            KeyDef("🌐", KeyType.LANG_SWITCH, 1f),
            KeyDef(","),
            KeyDef("스페이스", KeyType.SPACE, 3.5f),
            KeyDef("."),
            KeyDef("이동", KeyType.ENTER, 1.3f)
        )

    private fun row(vararg labels: String): MutableList<KeyDef> =
        labels.map { KeyDef(it) }.toMutableList()

    private fun toJson(layout: KeyboardLayout): String {
        val root = JSONObject()
        root.put("name", layout.name)
        val rowsArr = JSONArray()
        layout.rows.forEach { r ->
            val rowArr = JSONArray()
            r.forEach { key ->
                val k = JSONObject()
                k.put("label", key.label)
                k.put("type", key.type.name)
                k.put("weight", key.weight.toDouble())
                k.put("mark", key.mark)
                val popupArr = JSONArray()
                key.popup.forEach { popupArr.put(it) }
                k.put("popup", popupArr)
                rowArr.put(k)
            }
            rowsArr.put(rowArr)
        }
        root.put("rows", rowsArr)
        return root.toString()
    }

    private fun fromJson(json: String): KeyboardLayout {
        val root = JSONObject(json)
        val name = root.getString("name")
        val rowsArr = root.getJSONArray("rows")
        val rows = mutableListOf<MutableList<KeyDef>>()
        for (i in 0 until rowsArr.length()) {
            val rowArr = rowsArr.getJSONArray(i)
            val r = mutableListOf<KeyDef>()
            for (j in 0 until rowArr.length()) {
                val k = rowArr.getJSONObject(j)
                val popupArr = k.optJSONArray("popup")
                val popupList = mutableListOf<String>()
                if (popupArr != null) {
                    for (p in 0 until popupArr.length()) popupList.add(popupArr.getString(p))
                }
                r.add(
                    KeyDef(
                        label = k.getString("label"),
                        type = KeyType.valueOf(k.getString("type")),
                        weight = k.getDouble("weight").toFloat(),
                        popup = popupList,
                        mark = k.optString("mark", "")
                    )
                )
            }
            rows.add(r)
        }
        return KeyboardLayout(name, rows)
    }
}
