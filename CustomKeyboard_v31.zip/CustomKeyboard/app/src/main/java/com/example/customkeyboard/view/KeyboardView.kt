package com.example.customkeyboard.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.example.customkeyboard.model.BackgroundType
import com.example.customkeyboard.model.GradientDirection
import com.example.customkeyboard.model.KeyDef
import com.example.customkeyboard.model.KeyType
import com.example.customkeyboard.model.KeyboardLayout
import com.example.customkeyboard.model.KeyboardTheme

/**
 * 키보드를 직접 그리고 터치를 처리하는 커스텀 뷰.
 * - 테마(배경색/그라데이션/이미지, 버튼 색, 크기, 테두리)를 반영해서 그리고
 * - 누르면 시스템 표준 진동/클릭음을 재생하고
 * - 롱프레스 하면 추가 글자 팝업(일반 모드) 또는 편집용 롱프레스 콜백(편집 모드)이 동작합니다.
 *
 * 성능을 위해 그라데이션/이미지 셰이더는 매번 새로 만들지 않고, 테마나 크기가 바뀔 때만 다시 만들어서 캐시합니다.
 */
class KeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onKeyListener: ((KeyDef) -> Unit)? = null
    /** 설정하면 롱프레스 시 이 콜백만 호출되고(편집 모드용), 글자 팝업은 뜨지 않습니다. */
    var onKeyLongPressListener: ((KeyDef) -> Unit)? = null
    /** 탭한 키와, 그 키의 왼쪽/오른쪽 중 어디를 탭했는지까지 알려줍니다. (편집 화면의 "이동" 기능용) */
    var onKeyTapDetail: ((key: KeyDef, tapX: Float, keyRect: RectF) -> Unit)? = null
    /** 편집 화면에서 "이동 모드"로 선택된 키를 강조 표시할 때 사용합니다. */
    var highlightedKey: KeyDef? = null
        set(value) {
            field = value
            invalidate()
        }

    private var layoutModel: KeyboardLayout? = null
    private data class KeyRect(val rect: RectF, val key: KeyDef)
    private val keyRects = mutableListOf<KeyRect>()
    private var pressedKey: KeyDef? = null

    // 롱프레스 팝업 상태
    private var popupKey: KeyDef? = null
    private var popupRect: RectF? = null
    private var popupOptions: List<String> = emptyList() // 팝업 시작할 때 한 번만 만들어두고 재사용 (매 프레임 새로 안 만듦)
    private var popupSelectedIndex = -1 // -1 = 기본 글자, 0 이상 = popup 목록 인덱스
    private val handler = Handler(Looper.getMainLooper())
    private val longPressRunnable = Runnable { triggerLongPress() }
    private val longPressDelay = 280L
    private val popupBoxWidth = 100f
    private val popupBoxHeight = 100f
    private val popupMaxPerRow = 6

    private fun computePopupGridWidth(count: Int): Float = minOf(count, popupMaxPerRow) * popupBoxWidth
    private fun computePopupRows(count: Int): Int = (count + popupMaxPerRow - 1) / popupMaxPerRow

    // 백스페이스를 길게 누르면 빠르게 연속 삭제되도록 하는 상태
    private var backspaceRepeatStarted = false
    private val backspaceInitialDelay = 400L
    private val backspaceRepeatInterval = 50L
    private val backspaceRepeatRunnable = object : Runnable {
        override fun run() {
            val key = pressedKey ?: return
            if (key.type != KeyType.BACKSPACE) return
            backspaceRepeatStarted = true
            onKeyListener?.invoke(key)
            handler.postDelayed(this, backspaceRepeatInterval)
        }
    }

    private var theme = KeyboardTheme()
    private val keyGapBase = 6f
    private val rowHeightBase = 130f
    private val rowHeight get() = rowHeightBase * theme.keySizeScale
    private val keyGap get() = keyGapBase * theme.keyGapScale

    private var shiftActive = false
    private var capsLockActive = false

    /** 시프트가 한 번 눌렸는지(다음 한 글자만 대문자), Caps Lock인지(계속 대문자)를 알려줍니다. */
    fun setShiftState(active: Boolean, capsLock: Boolean) {
        shiftActive = active
        capsLockActive = capsLock
        invalidate()
    }

    private val normalBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val specialBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D8DCE0") }
    private val pressedBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B9C2CC") }
    private val highlightBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4C7CF0") }
    private val shiftOnceBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#AFC6EE") }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EDEFF2") }
    private val bgImagePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val keyBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val popupBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2B2F33") }
    private val popupSelectedBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4C7CF0") }
    private val popupTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 42f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1A1A1A")
        textAlign = Paint.Align.CENTER
        textSize = 48f
    }
    private val hintTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8A8F94")
        textAlign = Paint.Align.CENTER
        textSize = 22f
    }

    private var backgroundBitmap: Bitmap? = null
    private var backgroundBitmapUri: String? = null
    private var cachedCustomTypeface: Typeface? = null
    private var cachedCustomTypefaceUri: String? = null

    // 매 프레임 새로 만들지 않도록 캐시해두는 셰이더들 (성능 최적화)
    private var cachedBgShader: Shader? = null
    private var cachedBgShaderKey: String = ""
    private var cachedBorderShader: Shader? = null
    private var cachedBorderShaderKey: String = ""
    private var cachedKeyBorderUnitShader: Shader? = null
    private var cachedKeyBorderUnitShaderKey: String = ""

    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    init { isHapticFeedbackEnabled = true }

    fun setLayout(layout: KeyboardLayout) {
        layoutModel = layout
        // 화면 크기가 그대로면 onSizeChanged가 다시 호출되지 않으므로,
        // 여기서 직접 키 위치를 다시 계산해줘야 새 레이아웃이 화면에 반영됩니다.
        if (width > 0) {
            computeKeyRects(width.toFloat())
        }
        requestLayout()
        invalidate()
    }

    fun applyTheme(newTheme: KeyboardTheme) {
        theme = newTheme
        normalBg.color = theme.keyColor
        specialBg.color = theme.specialKeyColor
        textPaint.color = theme.textColor
        textPaint.textSize = 48f * theme.keySizeScale
        hintTextPaint.textSize = 22f * theme.keySizeScale
        bgPaint.color = theme.backgroundColor
        borderPaint.strokeWidth = theme.borderWidth
        borderPaint.color = theme.borderColor
        keyBorderPaint.strokeWidth = theme.keyBorderWidth
        keyBorderPaint.color = theme.keyBorderColor
        applyFont()
        loadBackgroundImageIfNeeded()
        invalidateShaderCache()
        requestLayout()
        if (width > 0) computeKeyRects(width.toFloat())
        invalidate()
    }

    private fun invalidateShaderCache() {
        cachedBgShader = null
        cachedBgShaderKey = ""
        cachedBorderShader = null
        cachedBorderShaderKey = ""
        cachedKeyBorderUnitShader = null
        cachedKeyBorderUnitShaderKey = ""
    }

    private fun applyFont() {
        val typeface = resolveTypeface()
        textPaint.typeface = typeface
        popupTextPaint.typeface = typeface
        hintTextPaint.typeface = typeface
    }

    private fun resolveTypeface(): Typeface {
        if (theme.fontFamily == "CUSTOM") {
            val uriStr = theme.customFontUri
            if (uriStr != null) {
                if (uriStr == cachedCustomTypefaceUri && cachedCustomTypeface != null) {
                    return cachedCustomTypeface!!
                }
                try {
                    context.contentResolver.openFileDescriptor(Uri.parse(uriStr), "r")?.use { pfd ->
                        val typeface = Typeface.Builder(pfd.fileDescriptor).build()
                        if (typeface != null) {
                            cachedCustomTypeface = typeface
                            cachedCustomTypefaceUri = uriStr
                            return typeface
                        }
                    }
                } catch (e: Exception) {
                    // 폰트 파일을 못 읽으면 기본 글꼴로 대체합니다.
                }
            }
            return Typeface.DEFAULT
        }
        return when (theme.fontFamily) {
            "SERIF" -> Typeface.SERIF
            "SANS_SERIF" -> Typeface.SANS_SERIF
            "MONOSPACE" -> Typeface.MONOSPACE
            else -> Typeface.DEFAULT
        }
    }

    private fun loadBackgroundImageIfNeeded() {
        if (theme.backgroundType != BackgroundType.IMAGE) return
        val uriStr = theme.backgroundImageUri ?: return
        if (uriStr == backgroundBitmapUri && backgroundBitmap != null) return
        try {
            context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { input ->
                backgroundBitmap = android.graphics.BitmapFactory.decodeStream(input)
                backgroundBitmapUri = uriStr
            }
        } catch (e: Exception) {
            backgroundBitmap = null
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val rows = layoutModel?.rows?.size ?: 4
        val height = (rowHeight * rows).toInt()
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeKeyRects(w.toFloat())
        invalidateShaderCache()
    }

    private fun computeKeyRects(width: Float) {
        keyRects.clear()
        val layout = layoutModel ?: return
        var y = 0f
        for (r in layout.rows) {
            val totalWeight = r.sumOf { it.weight.toDouble() }.toFloat().coerceAtLeast(0.01f)
            var x = 0f
            for (key in r) {
                val keyWidth = (width / totalWeight) * key.weight
                val rect = RectF(
                    x + keyGap / 2, y + keyGap / 2,
                    x + keyWidth - keyGap / 2, y + rowHeight - keyGap / 2
                )
                keyRects.add(KeyRect(rect, key))
                x += keyWidth
            }
            y += rowHeight
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawBackground(canvas)
        for (kr in keyRects) {
            val bg = when {
                kr.key === highlightedKey -> highlightBg
                kr.key === pressedKey -> pressedBg
                kr.key.type == KeyType.SHIFT && capsLockActive -> highlightBg
                kr.key.type == KeyType.SHIFT && shiftActive -> shiftOnceBg
                kr.key.type == KeyType.NORMAL -> normalBg
                else -> specialBg
            }
            canvas.drawRoundRect(kr.rect, 16f, 16f, bg)
            val displayLabel = if (shiftActive && kr.key.type == KeyType.NORMAL &&
                kr.key.label.length == 1 && kr.key.label[0].isLetter()
            ) {
                kr.key.label.uppercase()
            } else {
                kr.key.label
            }
            val cx = kr.rect.centerX()
            val cy = kr.rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2
            canvas.drawText(displayLabel, cx, cy, textPaint)
            if (kr.key.popup.isNotEmpty()) {
                canvas.drawText("•", kr.rect.right - 14f, kr.rect.top + 24f, hintTextPaint)
            }
            drawKeyBorderIfNeeded(canvas, kr.rect)
        }
        drawPopupIfNeeded(canvas)
        drawBorderIfNeeded(canvas)
    }

    private fun drawKeyBorderIfNeeded(canvas: Canvas, rect: RectF) {
        if (!theme.keyBorderEnabled || theme.keyBorderWidth <= 0f) return
        if (theme.keyBorderType == BackgroundType.GRADIENT && theme.keyBorderGradientColors.size >= 2) {
            val key = "keyborder-${theme.keyBorderGradientDirection}-${theme.keyBorderGradientColors}"
            if (cachedKeyBorderUnitShaderKey != key) {
                cachedKeyBorderUnitShader = makeShader(1f, 1f, BackgroundType.GRADIENT, theme.keyBorderGradientDirection, theme.keyBorderGradientColors)
                cachedKeyBorderUnitShaderKey = key
            }
            val shader = cachedKeyBorderUnitShader
            if (shader != null) {
                val matrix = Matrix()
                matrix.setScale(rect.width(), rect.height())
                matrix.postTranslate(rect.left, rect.top)
                shader.setLocalMatrix(matrix)
                keyBorderPaint.shader = shader
            }
        } else {
            keyBorderPaint.shader = null
        }
        canvas.drawRoundRect(rect, 16f, 16f, keyBorderPaint)
    }

    private fun makeShader(w: Float, h: Float, type: BackgroundType, direction: GradientDirection, colors: List<Int>): Shader? {
        if (type != BackgroundType.GRADIENT || colors.size < 2) return null
        val colorArr = colors.toIntArray()
        return when (direction) {
            GradientDirection.TOP_TO_BOTTOM -> LinearGradient(0f, 0f, 0f, h, colorArr, null, Shader.TileMode.CLAMP)
            GradientDirection.LEFT_TO_RIGHT -> LinearGradient(0f, 0f, w, 0f, colorArr, null, Shader.TileMode.CLAMP)
            GradientDirection.DIAGONAL -> LinearGradient(0f, 0f, w, h, colorArr, null, Shader.TileMode.CLAMP)
            GradientDirection.RADIAL -> {
                val radius = (maxOf(w, h) / 1.5f).coerceAtLeast(1f)
                RadialGradient(w / 2f, h / 2f, radius, colorArr, null, Shader.TileMode.CLAMP)
            }
        }
    }

    private fun drawBackground(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        when (theme.backgroundType) {
            BackgroundType.SOLID -> canvas.drawRect(0f, 0f, w, h, bgPaint)
            BackgroundType.GRADIENT -> {
                val key = "bg-${theme.gradientDirection}-${theme.gradientColors}-$w-$h"
                if (cachedBgShaderKey != key) {
                    cachedBgShader = makeShader(w, h, BackgroundType.GRADIENT, theme.gradientDirection, theme.gradientColors)
                    cachedBgShaderKey = key
                }
                bgPaint.shader = cachedBgShader
                canvas.drawRect(0f, 0f, w, h, bgPaint)
            }
            BackgroundType.IMAGE -> {
                val bmp = backgroundBitmap
                if (bmp != null && w > 0 && h > 0) {
                    val key = "img-$backgroundBitmapUri-$w-$h"
                    if (cachedBgShaderKey != key) {
                        val shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                        val scale = maxOf(w / bmp.width, h / bmp.height)
                        val matrix = Matrix()
                        matrix.setScale(scale, scale)
                        matrix.postTranslate((w - bmp.width * scale) / 2f, (h - bmp.height * scale) / 2f)
                        shader.setLocalMatrix(matrix)
                        cachedBgShader = shader
                        cachedBgShaderKey = key
                    }
                    bgImagePaint.shader = cachedBgShader
                    canvas.drawRect(0f, 0f, w, h, bgImagePaint)
                } else {
                    canvas.drawRect(0f, 0f, w, h, bgPaint)
                }
            }
        }
    }

    private fun drawBorderIfNeeded(canvas: Canvas) {
        if (!theme.borderEnabled || theme.borderWidth <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val half = theme.borderWidth / 2f
        if (theme.borderType == BackgroundType.GRADIENT && theme.borderGradientColors.size >= 2) {
            val key = "border-${theme.borderGradientDirection}-${theme.borderGradientColors}-$w-$h"
            if (cachedBorderShaderKey != key) {
                cachedBorderShader = makeShader(w, h, BackgroundType.GRADIENT, theme.borderGradientDirection, theme.borderGradientColors)
                cachedBorderShaderKey = key
            }
            borderPaint.shader = cachedBorderShader
        } else {
            borderPaint.shader = null
            borderPaint.color = theme.borderColor
        }
        canvas.drawRect(half, half, w - half, h - half, borderPaint)
    }

    /** 팝업 상자가 화면(키보드) 밖으로 나가지 않도록, 왼쪽/오른쪽 가장자리에서는 위치를 안쪽으로 당겨줍니다. */
    private fun computePopupLeft(rect: RectF, totalWidth: Float): Float {
        val idealLeft = rect.centerX() - totalWidth / 2
        val maxLeft = (width - totalWidth).coerceAtLeast(0f)
        return idealLeft.coerceIn(0f, maxLeft)
    }

    /** 위쪽에 공간이 모자라면(예: 맨 위쪽 줄의 키) 팝업을 아래쪽에 띄웁니다. */
    private fun isPopupBelowKey(rect: RectF, popupHeight: Float): Boolean {
        return (rect.top - 12f - popupHeight) < 0f
    }

    private fun popupRowTop(rect: RectF, rowFromEdge: Int, below: Boolean): Float {
        return if (below) {
            rect.bottom + 12f + rowFromEdge * popupBoxHeight
        } else {
            (rect.top - 12f) - (rowFromEdge + 1) * popupBoxHeight
        }
    }

    private fun drawPopupIfNeeded(canvas: Canvas) {
        if (popupKey == null) return
        val rect = popupRect ?: return
        val options = popupOptions
        val count = options.size
        val gridWidth = computePopupGridWidth(count)
        val left = computePopupLeft(rect, gridWidth)
        val rows = computePopupRows(count)
        val popupHeight = rows * popupBoxHeight
        val below = isPopupBelowKey(rect, popupHeight)

        for (i in options.indices) {
            val rowFromEdge = i / popupMaxPerRow
            val col = i % popupMaxPerRow
            val top = popupRowTop(rect, rowFromEdge, below)
            val optLeft = left + col * popupBoxWidth
            val optRect = RectF(optLeft, top, optLeft + popupBoxWidth, top + popupBoxHeight)
            val bg = if (i - 1 == popupSelectedIndex) popupSelectedBg else popupBg
            canvas.drawRoundRect(optRect, 14f, 14f, bg)
            val cx = optRect.centerX()
            val cy = optRect.centerY() - (popupTextPaint.descent() + popupTextPaint.ascent()) / 2
            canvas.drawText(options[i], cx, cy, popupTextPaint)
        }
    }

    private fun triggerLongPress() {
        val kr = keyRects.firstOrNull { it.key === pressedKey } ?: return
        if (onKeyLongPressListener != null) {
            onKeyLongPressListener?.invoke(kr.key)
            pressedKey = null
            invalidate()
            return
        }
        if (kr.key.popup.isEmpty()) return
        popupKey = kr.key
        popupRect = kr.rect
        popupOptions = listOf(kr.key.label) + kr.key.popup
        popupSelectedIndex = -1
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(longPressRunnable)
                handler.removeCallbacks(backspaceRepeatRunnable)
                backspaceRepeatStarted = false
                popupKey = null
                val found = keyRects.firstOrNull { it.rect.contains(event.x, event.y) }
                pressedKey = found?.key
                if (found != null) {
                    performHapticFeedback(
                        HapticFeedbackConstants.KEYBOARD_TAP,
                        HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                    )
                    audioManager.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
                    if (found.key.popup.isNotEmpty() || onKeyLongPressListener != null) {
                        handler.postDelayed(longPressRunnable, longPressDelay)
                    }
                    if (found.key.type == KeyType.BACKSPACE && onKeyLongPressListener == null) {
                        handler.postDelayed(backspaceRepeatRunnable, backspaceInitialDelay)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                handler.removeCallbacks(longPressRunnable)
                handler.removeCallbacks(backspaceRepeatRunnable)
                pressedKey = null
                popupKey = null
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (popupKey != null) {
                    val options = popupOptions
                    val count = options.size
                    val gridWidth = computePopupGridWidth(count)
                    val rect = popupRect!!
                    val left = computePopupLeft(rect, gridWidth)
                    val rows = computePopupRows(count)
                    val popupHeight = rows * popupBoxHeight
                    val below = isPopupBelowKey(rect, popupHeight)

                    var col = ((event.x - left) / popupBoxWidth).toInt()
                    if (col < 0) col = 0
                    if (col > popupMaxPerRow - 1) col = popupMaxPerRow - 1

                    var rowFromEdge = if (below) {
                        ((event.y - (rect.bottom + 12f)) / popupBoxHeight).toInt()
                    } else {
                        ((rect.top - 12f - event.y) / popupBoxHeight).toInt()
                    }
                    val maxRow = rows - 1
                    if (rowFromEdge < 0) rowFromEdge = 0
                    if (rowFromEdge > maxRow) rowFromEdge = maxRow

                    var idx = rowFromEdge * popupMaxPerRow + col
                    if (idx > options.lastIndex) idx = options.lastIndex
                    popupSelectedIndex = idx - 1
                    invalidate()
                } else {
                    val stillOnKey = pressedKey != null &&
                        keyRects.firstOrNull { it.key === pressedKey }?.rect?.contains(event.x, event.y) == true
                    if (!stillOnKey) {
                        handler.removeCallbacks(longPressRunnable)
                        handler.removeCallbacks(backspaceRepeatRunnable)
                        pressedKey = null
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                handler.removeCallbacks(backspaceRepeatRunnable)
                if (popupKey != null) {
                    val chosenLabel = if (popupSelectedIndex == -1) {
                        popupKey!!.label
                    } else {
                        popupKey!!.popup.getOrElse(popupSelectedIndex) { popupKey!!.label }
                    }
                    onKeyListener?.invoke(KeyDef(chosenLabel, KeyType.NORMAL))
                    popupKey = null
                } else if (!backspaceRepeatStarted) {
                    val key = pressedKey
                    if (key != null) {
                        onKeyListener?.invoke(key)
                        val kr = keyRects.firstOrNull { it.key === key }
                        if (kr != null) onKeyTapDetail?.invoke(key, event.x, kr.rect)
                    }
                }
                pressedKey = null
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                handler.removeCallbacks(backspaceRepeatRunnable)
                pressedKey = null
                popupKey = null
                invalidate()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacksAndMessages(null)
    }
}
