package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray

/** 최근에 사용한 이모지를 기억해두는 저장소. */
object RecentEmojiStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_RECENT = "recent_emoji"
    private const val MAX_ITEMS = 60

    fun getRecent(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_RECENT, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addUsed(context: Context, emoji: String) {
        if (emoji.isBlank()) return
        val current = getRecent(context).toMutableList()
        current.remove(emoji)
        current.add(0, emoji)
        while (current.size > MAX_ITEMS) current.removeAt(current.size - 1)
        save(context, current)
    }

    fun clear(context: Context) {
        save(context, emptyList())
    }

    private fun save(context: Context, items: List<String>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        prefs.edit().putString(KEY_RECENT, arr.toString()).apply()
    }
}
