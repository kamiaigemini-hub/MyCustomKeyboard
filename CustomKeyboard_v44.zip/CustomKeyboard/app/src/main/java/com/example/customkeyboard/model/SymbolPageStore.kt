package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray

/**
 * 특수문자(123) 화면을 여러 페이지로 나눠서 관리합니다.
 * 삼성 키보드의 기호 1/2, 2/2 페이지처럼, 페이지를 추가하고 그 사이를 이동할 수 있어요.
 */
object SymbolPageStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_PAGES = "symbol_pages"

    fun getPages(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_PAGES, null) ?: return listOf("symbols")
        return try {
            val arr = JSONArray(json)
            val list = (0 until arr.length()).map { arr.getString(it) }
            if (list.isEmpty()) listOf("symbols") else list
        } catch (e: Exception) {
            listOf("symbols")
        }
    }

    /** 새 특수문자 페이지를 추가하고, 새로 만든 페이지의 코드를 돌려줍니다. */
    fun addPage(context: Context): String {
        val pages = getPages(context).toMutableList()
        var n = pages.size + 1
        var newCode = "symbols$n"
        while (pages.contains(newCode)) {
            n++
            newCode = "symbols$n"
        }
        pages.add(newCode)
        save(context, pages)
        return newCode
    }

    /** 특수문자 페이지를 삭제합니다. 첫 페이지("symbols")는 삭제할 수 없어요. */
    fun removePage(context: Context, code: String) {
        if (code == "symbols") return
        val pages = getPages(context).toMutableList()
        pages.remove(code)
        if (pages.isEmpty()) pages.add("symbols")
        save(context, pages)
        LayoutStore.resetLayout(context, code)
    }

    private fun save(context: Context, pages: List<String>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        pages.forEach { arr.put(it) }
        prefs.edit().putString(KEY_PAGES, arr.toString()).apply()
    }
}
