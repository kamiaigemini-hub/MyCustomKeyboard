package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 기본으로 들어있는 이모지 카테고리(스마일리, 사람 등) 말고,
 * 사용자가 직접 추가한 이모지 페이지를 관리합니다.
 */
object EmojiPageStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_CUSTOM = "emoji_custom_pages"

    fun getCustomPages(context: Context): List<Pair<String, String>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CUSTOM, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.getString("code") to o.getString("name")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** 새 이모지 페이지를 추가하고, 새로 만든 페이지의 (코드, 이름)을 돌려줍니다. 처음엔 빈 페이지로 시작해요. */
    fun addPage(context: Context, displayName: String): Pair<String, String> {
        val code = "emoji_custom_${System.currentTimeMillis()}"
        val current = getCustomPages(context).toMutableList()
        current.add(code to displayName)
        save(context, current)
        return code to displayName
    }

    /** 사용자가 만든 이모지 페이지를 완전히 삭제합니다. (기본 카테고리는 삭제할 수 없어요.) */
    fun removePage(context: Context, code: String) {
        val current = getCustomPages(context).filter { it.first != code }
        save(context, current)
        LayoutStore.resetLayout(context, code)
    }

    private fun save(context: Context, pages: List<Pair<String, String>>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        pages.forEach {
            val o = JSONObject()
            o.put("code", it.first)
            o.put("name", it.second)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }
}
