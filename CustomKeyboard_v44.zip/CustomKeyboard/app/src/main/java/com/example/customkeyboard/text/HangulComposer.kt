package com.example.customkeyboard.text

import android.view.inputmethod.InputConnection

/**
 * 한글 자음/모음을 실시간으로 완성형 글자로 합쳐주는 엔진.
 * 예: ㄱ -> ㄱ+ㅏ="가" -> 가+ㄴ="간" -> 간+ㅏ="가"+"나"(간의 ㄴ이 다음 글자의 초성이 됨)
 *
 * 성능 참고: 예전에는 "${a}${b}" 처럼 매 키 입력마다 문자열을 새로 만들어서 Map을 찾았는데,
 * 그러면 키를 누를 때마다 메모리를 계속 새로 잡아먹게 됩니다. 지금은 문자열/Map 없이
 * when(){} 분기만으로 바로 결과를 돌려줘서, 조합/분해 확인에 새 객체를 전혀 만들지 않습니다.
 *
 * getIC: 현재 입력창(InputConnection)을 가져오는 함수. IME에서 넘겨줍니다.
 */
class HangulComposer(private val getIC: () -> InputConnection?) {

    companion object {
        const val CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
        const val JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
        const val JONG = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"

        /** 모음 두 개를 합쳐서 이중모음을 만듭니다. 합칠 수 없으면 null. (새 객체 생성 없음) */
        fun combineJung(base: Char, add: Char): Char? = when (base) {
            'ㅗ' -> when (add) { 'ㅏ' -> 'ㅘ'; 'ㅐ' -> 'ㅙ'; 'ㅣ' -> 'ㅚ'; else -> null }
            'ㅜ' -> when (add) { 'ㅓ' -> 'ㅝ'; 'ㅔ' -> 'ㅞ'; 'ㅣ' -> 'ㅟ'; else -> null }
            'ㅡ' -> if (add == 'ㅣ') 'ㅢ' else null
            else -> null
        }

        /** 이중모음을 원래 두 모음으로 되돌립니다(백스페이스용). 첫 번째 값이 남는 모음. */
        fun decomposeJung(combined: Char): Char? = when (combined) {
            'ㅘ', 'ㅙ', 'ㅚ' -> 'ㅗ'
            'ㅝ', 'ㅞ', 'ㅟ' -> 'ㅜ'
            'ㅢ' -> 'ㅡ'
            else -> null
        }

        /** 받침 두 개를 합쳐서 겹받침을 만듭니다. 합칠 수 없으면 null. */
        fun combineJong(base: Char, add: Char): Char? = when (base) {
            'ㄱ' -> if (add == 'ㅅ') 'ㄳ' else null
            'ㄴ' -> when (add) { 'ㅈ' -> 'ㄵ'; 'ㅎ' -> 'ㄶ'; else -> null }
            'ㄹ' -> when (add) {
                'ㄱ' -> 'ㄺ'; 'ㅁ' -> 'ㄻ'; 'ㅂ' -> 'ㄼ'; 'ㅅ' -> 'ㄽ'
                'ㅌ' -> 'ㄾ'; 'ㅍ' -> 'ㄿ'; 'ㅎ' -> 'ㅀ'; else -> null
            }
            'ㅂ' -> if (add == 'ㅅ') 'ㅄ' else null
            else -> null
        }

        /** 겹받침을 (남는 받침, 다음 글자 초성이 될 자음)으로 나눕니다. */
        fun decomposeJongFirst(combined: Char): Char? = when (combined) {
            'ㄳ' -> 'ㄱ'; 'ㄵ', 'ㄶ' -> 'ㄴ'
            'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ' -> 'ㄹ'
            'ㅄ' -> 'ㅂ'
            else -> null
        }

        fun decomposeJongSecond(combined: Char): Char? = when (combined) {
            'ㄳ' -> 'ㅅ'
            'ㄵ' -> 'ㅈ'; 'ㄶ' -> 'ㅎ'
            'ㄺ' -> 'ㄱ'; 'ㄻ' -> 'ㅁ'; 'ㄼ' -> 'ㅂ'; 'ㄽ' -> 'ㅅ'
            'ㄾ' -> 'ㅌ'; 'ㄿ' -> 'ㅍ'; 'ㅀ' -> 'ㅎ'
            'ㅄ' -> 'ㅅ'
            else -> null
        }
    }

    private var cho: Char? = null
    private var jung: Char? = null
    private var jong: Char? = null

    /** 자음이나 모음 한 글자를 입력받아 조합을 진행합니다. */
    fun inputJamo(ch: Char) {
        val isCho = CHO.contains(ch)
        val isJung = JUNG.contains(ch)
        if (!isCho && !isJung) return

        if (isJung) {
            when {
                jong != null -> {
                    // 받침이 있는 상태에서 모음이 오면, 받침을 다음 글자의 초성으로 넘겨줍니다.
                    val curJong = jong!!
                    val remain = decomposeJongFirst(curJong)
                    val newCho: Char
                    if (remain != null) {
                        jong = remain
                        newCho = decomposeJongSecond(curJong)!!
                    } else {
                        newCho = curJong
                        jong = null
                    }
                    commitCurrent()
                    cho = newCho
                    jung = ch
                }
                jung != null -> {
                    val combined = combineJung(jung!!, ch)
                    if (combined != null) {
                        jung = combined
                    } else {
                        commitCurrent()
                        jung = ch
                    }
                }
                else -> {
                    jung = ch
                }
            }
        } else {
            when {
                jong != null -> {
                    val combined = combineJong(jong!!, ch)
                    if (combined != null) {
                        jong = combined
                    } else {
                        commitCurrent()
                        cho = ch
                    }
                }
                jung != null -> {
                    if (cho != null) {
                        jong = ch
                    } else {
                        // 모음만 있고 초성이 아직 없는 상태에서 자음이 오면,
                        // 그 자음을 초성으로 붙여서 바로 완성된 글자를 만듭니다. (예: ㅏ + ㅇ = 아)
                        cho = ch
                    }
                }
                cho != null -> {
                    commitCurrent()
                    cho = ch
                }
                else -> {
                    cho = ch
                }
            }
        }
        updateComposing()
    }

    /** 백스페이스 처리. 조합 중인 글자가 있으면 한 조각씩 지우고 true를 반환합니다. */
    fun backspace(): Boolean {
        if (jong != null) {
            jong = null
            updateComposing()
            return true
        }
        if (jung != null) {
            jung = decomposeJung(jung!!)
            updateComposing()
            return true
        }
        if (cho != null) {
            cho = null
            updateComposing()
            return true
        }
        return false
    }

    /** 조합 중인 글자를 확정해서 입력창에 보냅니다. (스페이스/엔터/다른 언어 전환 등에서 호출) */
    fun commit() {
        commitCurrent()
    }

    /**
     * 상대 앱에 아무것도 보내지 않고, 조합 중이던 상태만 그냥 지웁니다.
     * 키보드를 껐다가 새로 열었을 때(새로운 입력창) 예전 상태가 남아있어서
     * 새 글자랑 섞여 들어가는 것을 막기 위해 씁니다.
     */
    fun reset() {
        cho = null
        jung = null
        jong = null
    }

    private fun commitCurrent() {
        val ic = getIC() ?: return
        val text = currentText()
        if (text.isNotEmpty()) {
            ic.commitText(text, 1)
        } else {
            ic.finishComposingText()
        }
        cho = null
        jung = null
        jong = null
    }

    private fun updateComposing() {
        val ic = getIC() ?: return
        ic.setComposingText(currentText(), 1)
    }

    private fun currentText(): String {
        if (cho == null && jung == null) return ""
        if (cho != null && jung != null) {
            val choIdx = CHO.indexOf(cho!!)
            val jungIdx = JUNG.indexOf(jung!!)
            val jongIdx = if (jong == null) 0 else JONG.indexOf(jong!!)
            val code = 0xAC00 + (choIdx * 21 + jungIdx) * 28 + jongIdx
            return code.toChar().toString()
        }
        return (cho ?: jung).toString()
    }
}
