package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 어떤 언어가 "설치"(켜짐) 되어 있는지 관리하고,
 * 사용자가 직접 새 언어를 추가/삭제할 수 있게 해줍니다.
 */
object LanguageStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_INSTALLED = "installed_languages"
    private const val KEY_CUSTOM = "custom_languages"
    private const val KEY_NAME_OVERRIDES = "language_name_overrides"

    // 앱에 기본으로 들어있는 언어 (한국어는 자모 조합 엔진 사용)
    val ALL: List<LanguageDef> = listOf(
        LanguageDef("ko", "한국어", isHangul = true),
        LanguageDef("ko_cheonjiin", "한국어 (천지인)", isHangul = true, isCheonjiin = true),
        LanguageDef("en", "English"),
        LanguageDef("vi", "Tiếng Việt (베트남어)", isViTone = true),
        LanguageDef("zalgo", "Zalgo")
    )

    fun customLanguages(context: Context): List<LanguageDef> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CUSTOM, null) ?: return emptyList()
        val arr = JSONArray(json)
        val list = mutableListOf<LanguageDef>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(LanguageDef(o.getString("code"), o.getString("name")))
        }
        return list
    }

    /** 언어 이름을 직접 지정한 것들 (기본 언어든 사용자가 만든 언어든 다 바꿀 수 있어요). */
    fun getNameOverrides(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_NAME_OVERRIDES, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(json)
            val map = mutableMapOf<String, String>()
            obj.keys().forEach { k -> map[k] = obj.getString(k) }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /** 언어 이름을 바꿉니다. 빈 문자열을 주면 원래 이름으로 되돌립니다. */
    fun setDisplayName(context: Context, code: String, name: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = getNameOverrides(context).toMutableMap()
        if (name.isBlank()) current.remove(code) else current[code] = name
        val obj = JSONObject()
        current.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit().putString(KEY_NAME_OVERRIDES, obj.toString()).apply()
    }

    /** 기본 언어 + 사용자가 추가한 언어를 모두 합친 전체 목록. 바꾼 이름이 있으면 그 이름으로 보여줍니다. */
    fun allLanguages(context: Context): List<LanguageDef> {
        val overrides = getNameOverrides(context)
        val base = ALL + customLanguages(context)
        return base.map { def ->
            val override = overrides[def.code]
            if (override != null) def.copy(displayName = override) else def
        }
    }

    /** 새 언어를 추가합니다. 영어 자판을 복사한 빈 틀로 시작해서, 바로 편집할 수 있어요. */
    fun addCustomLanguage(context: Context, displayName: String): LanguageDef {
        val code = "custom_${System.currentTimeMillis()}"
        val newLang = LanguageDef(code, displayName)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        (customLanguages(context) + newLang).forEach {
            val o = JSONObject()
            o.put("code", it.code)
            o.put("name", it.displayName)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
        setInstalled(context, code, true)
        return newLang
    }

    /** 사용자가 만든 언어를 완전히 삭제합니다 (기본 언어는 삭제 불가, 켜고 끄기만 가능). */
    fun removeCustomLanguage(context: Context, code: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val remaining = customLanguages(context).filter { it.code != code }
        val arr = JSONArray()
        remaining.forEach {
            val o = JSONObject()
            o.put("code", it.code)
            o.put("name", it.displayName)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
        setInstalled(context, code, false)
        LayoutStore.resetLayout(context, code)
    }

    fun installedCodes(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_INSTALLED, null) ?: setOf("ko", "en")
    }

    fun setInstalled(context: Context, code: String, installed: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = installedCodes(context).toMutableSet()
        if (installed) current.add(code) else current.remove(code)
        if (current.isEmpty()) current.add("en") // 최소 1개는 항상 남겨둠
        prefs.edit().putStringSet(KEY_INSTALLED, current).apply()
    }

    fun installedLanguages(context: Context): List<LanguageDef> {
        val codes = installedCodes(context)
        return allLanguages(context).filter { it.code in codes }
    }

    fun defByCode(context: Context, code: String): LanguageDef =
        allLanguages(context).firstOrNull { it.code == code } ?: ALL[1]
}
