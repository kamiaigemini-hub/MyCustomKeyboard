package com.example.customkeyboard

import android.content.ClipboardManager
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.customkeyboard.model.ClipboardStore
import com.example.customkeyboard.model.KeyDef
import com.example.customkeyboard.model.KeyType
import com.example.customkeyboard.model.KeyboardLayout
import com.example.customkeyboard.model.LanguageDef
import com.example.customkeyboard.model.LanguageStore
import com.example.customkeyboard.model.LayoutStore
import com.example.customkeyboard.model.SymbolPageStore
import com.example.customkeyboard.model.ThemeStore
import com.example.customkeyboard.text.CheonjiinProcessor
import com.example.customkeyboard.text.DiacriticComposer
import com.example.customkeyboard.text.HangulComposer
import com.example.customkeyboard.view.KeyboardView

/**
 * 실제 키보드 서비스. 시스템이 텍스트 입력창에 포커스가 잡히면
 * 이 서비스가 onCreateInputView()로 만든 뷰를 화면 하단에 띄웁니다.
 */
class KeyboardIME : InputMethodService() {

    private enum class ShiftState { OFF, ONCE, CAPS_LOCK }

    private lateinit var container: LinearLayout
    private lateinit var keyboardView: KeyboardView
    private lateinit var clipboardHeaderRow: LinearLayout
    private lateinit var clipboardToggleButton: Button
    private lateinit var emojiToggleButton: Button
    private lateinit var clipboardStripScroll: HorizontalScrollView
    private lateinit var clipboardStripContainer: LinearLayout
    private lateinit var emojiPanelScroll: ScrollView
    private lateinit var emojiPanelContainer: LinearLayout
    private lateinit var symbolsLayout: KeyboardLayout
    private lateinit var currentLayout: KeyboardLayout
    private var currentLangCode: String = "ko"
    private var currentLang: LanguageDef = LanguageStore.ALL[0]
    private var isSymbolsMode = false
    private var symbolsPageIndex = 0
    private var isClipboardOpen = false
    private var isEmojiOpen = false
    private var clipboardMoveSource: String? = null
    private var shiftState = ShiftState.OFF

    private val hangulComposer by lazy(LazyThreadSafetyMode.NONE) { HangulComposer { currentInputConnection } }
    private val cheonjiinProcessor by lazy(LazyThreadSafetyMode.NONE) { CheonjiinProcessor(hangulComposer) }
    private val diacriticComposer by lazy(LazyThreadSafetyMode.NONE) { DiacriticComposer { currentInputConnection } }

    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = cm?.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) {
                ClipboardStore.addEntry(this, text)
                if (isClipboardOpen) refreshClipboardStrip()
            }
        }
    }

    override fun onCreateInputView(): View {
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keyboardView = KeyboardView(this)
        keyboardView.onKeyListener = { key -> handleKey(key) }

        clipboardHeaderRow = buildClipboardHeaderRow()
        clipboardStripScroll = buildClipboardStrip()
        clipboardStripScroll.visibility = View.GONE
        emojiPanelScroll = buildEmojiPanel()
        emojiPanelScroll.visibility = View.GONE
        container.addView(clipboardHeaderRow)
        container.addView(clipboardStripScroll)
        container.addView(emojiPanelScroll)
        container.addView(keyboardView)

        loadCurrentLanguage()

        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.addPrimaryClipChangedListener(clipboardListener)

        return container
    }

    override fun onDestroy() {
        super.onDestroy()
        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.removePrimaryClipChangedListener(clipboardListener)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        isSymbolsMode = false
        symbolsPageIndex = 0
        setShiftState(ShiftState.OFF)
        closeClipboardStrip()
        closeEmojiPanel()
        loadCurrentLanguage()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        loadCurrentLanguage()
    }

    private fun loadCurrentLanguage() {
        val installed = LanguageStore.installedLanguages(this)
        if (installed.none { it.code == currentLangCode }) {
            currentLangCode = installed.firstOrNull()?.code ?: "en"
        }
        currentLang = LanguageStore.defByCode(this, currentLangCode)
        currentLayout = LayoutStore.loadLayout(this, currentLangCode)
        val symbolPages = SymbolPageStore.getPages(this)
        if (symbolsPageIndex >= symbolPages.size) symbolsPageIndex = 0
        symbolsLayout = LayoutStore.loadLayout(this, symbolPages[symbolsPageIndex])
        val theme = ThemeStore.load(this)
        keyboardView.applyTheme(theme)
        keyboardView.setLayout(if (isSymbolsMode) symbolsLayout else currentLayout)
        clipboardToggleButton.setBackgroundColor(theme.specialKeyColor)
        clipboardToggleButton.setTextColor(theme.textColor)
        emojiToggleButton.setBackgroundColor(theme.specialKeyColor)
        emojiToggleButton.setTextColor(theme.textColor)
        clipboardHeaderRow.setBackgroundColor(theme.backgroundColor)
    }

    private fun setShiftState(state: ShiftState) {
        shiftState = state
        keyboardView.setShiftState(state != ShiftState.OFF, state == ShiftState.CAPS_LOCK)
    }

    private fun handleKey(key: KeyDef) {
        val ic = currentInputConnection ?: return
        // 한 번 키를 누를 때 생기는 여러 단계(지우기+새로 넣기 등)를 한 묶음으로 상대 앱에 전달해서
        // 상대 앱이 매번 다시 그리는 걸 줄여줍니다. (삼성 키보드 등이 쓰는 표준 기법)
        ic.beginBatchEdit()
        try {
            handleKeyInternal(key, ic)
        } finally {
            ic.endBatchEdit()
        }
    }

    private fun handleKeyInternal(key: KeyDef, ic: android.view.inputmethod.InputConnection) {
        val lang = currentLang

        // 백스페이스: 조합 중인 게 있으면 한 조각씩 지웁니다.
        if (key.type == KeyType.BACKSPACE) {
            if (lang.isCheonjiin && cheonjiinProcessor.backspace()) return
            if (lang.isHangul && !lang.isCheonjiin && hangulComposer.backspace()) return
            diacriticComposer.reset()
            deleteOneCharacter(ic)
            return
        }

        // 클립보드 열기/닫기
        if (key.type == KeyType.CLIPBOARD_TOGGLE) {
            if (isClipboardOpen) closeClipboardStrip() else openClipboardStrip()
            return
        }

        // 방향키: 좌우는 커서 위치를 직접 지정해서(더 확실한 방법) 옮기고, 위아래는 방향키 신호를 보냅니다.
        if (key.type == KeyType.CURSOR_MOVE) {
            if (lang.isCheonjiin) cheonjiinProcessor.commitAll()
            else if (lang.isHangul) hangulComposer.commit()
            else diacriticComposer.reset()
            moveCursor(ic, key.mark)
            return
        }

        // 천지인 자음 키 (같은 키를 반복해서 누르면 ㄱ→ㅋ→ㄲ 순환)
        if (lang.isCheonjiin && key.type == KeyType.CHEONJIIN_CONS) {
            val group = key.popup.mapNotNull { it.firstOrNull() }
            cheonjiinProcessor.pressConsonant(group)
            return
        }

        // 천지인 모음 획 키 (ㅣ, ㆍ, ㅡ를 합쳐서 모음을 만듭니다)
        if (lang.isCheonjiin && key.type == KeyType.CHEONJIIN_STROKE && key.label.isNotEmpty()) {
            cheonjiinProcessor.pressStroke(key.label[0])
            return
        }

        // 조합 키 (모든 언어에서 공통으로 작동: 바로 앞에 친 글자에 합쳐집니다)
        if (key.type == KeyType.DIACRITIC) {
            diacriticComposer.applyDiacritic(key.mark)
            return
        }

        // 일반 한글(2벌식) 모드에서 자음/모음이면 조합 엔진으로 보냅니다.
        if (lang.isHangul && !lang.isCheonjiin && key.type == KeyType.NORMAL && key.label.length == 1 &&
            (HangulComposer.CHO.contains(key.label[0]) || HangulComposer.JUNG.contains(key.label[0]))
        ) {
            hangulComposer.inputJamo(key.label[0])
            return
        }

        // 그 외의 키(숫자, 기호, 스페이스, 엔터 등)를 누르면 조합 중이던 글자를 먼저 확정합니다.
        if (lang.isCheonjiin) cheonjiinProcessor.commitAll()
        else if (lang.isHangul) hangulComposer.commit()
        else if (key.type != KeyType.NORMAL) diacriticComposer.reset()

        when (key.type) {
            KeyType.NORMAL -> {
                val text = if (shiftState != ShiftState.OFF && key.label.length == 1 && key.label[0].isLetter()) {
                    key.label.uppercase()
                } else {
                    key.label
                }
                ic.commitText(text, 1)
                if (shiftState == ShiftState.ONCE) setShiftState(ShiftState.OFF)
                if (text.length == 1) {
                    diacriticComposer.onBaseLetterTyped(text[0])
                } else {
                    diacriticComposer.reset()
                }
            }
            KeyType.SPACE -> ic.commitText(" ", 1)
            KeyType.SHIFT -> {
                // 1번 누르면 다음 한 글자만 대문자, 2번째 누르면 계속 대문자(Caps Lock), 3번째 누르면 다시 소문자.
                val next = when (shiftState) {
                    ShiftState.OFF -> ShiftState.ONCE
                    ShiftState.ONCE -> ShiftState.CAPS_LOCK
                    ShiftState.CAPS_LOCK -> ShiftState.OFF
                }
                setShiftState(next)
            }
            KeyType.ENTER -> {
                val info = currentInputEditorInfo
                if (info != null) {
                    val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
                    if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                        ic.performEditorAction(action)
                    } else {
                        ic.commitText("\n", 1)
                    }
                } else {
                    ic.commitText("\n", 1)
                }
            }
            KeyType.SYMBOLS_TOGGLE -> {
                isSymbolsMode = !isSymbolsMode
                keyboardView.setLayout(if (isSymbolsMode) symbolsLayout else currentLayout)
            }
            KeyType.LANG_SWITCH -> {
                val installed = LanguageStore.installedLanguages(this)
                if (installed.size > 1) {
                    val idx = installed.indexOfFirst { it.code == currentLangCode }
                    val next = installed[(idx + 1) % installed.size]
                    currentLangCode = next.code
                    currentLang = next
                    isSymbolsMode = false
                    setShiftState(ShiftState.OFF)
                    currentLayout = LayoutStore.loadLayout(this, currentLangCode)
                    keyboardView.setLayout(currentLayout)
                }
            }
            KeyType.SYMBOLS_PAGE_SWITCH -> {
                val pages = SymbolPageStore.getPages(this)
                if (pages.size > 1) {
                    symbolsPageIndex = if (key.mark == "PREV") {
                        (symbolsPageIndex - 1 + pages.size) % pages.size
                    } else {
                        (symbolsPageIndex + 1) % pages.size
                    }
                    symbolsLayout = LayoutStore.loadLayout(this, pages[symbolsPageIndex])
                    keyboardView.setLayout(symbolsLayout)
                }
            }
            else -> { /* 위에서 이미 처리됨 (BACKSPACE, CLIPBOARD_TOGGLE, CHEONJIIN_CONS, CHEONJIIN_STROKE, DIACRITIC) */ }
        }
    }

    /**
     * 커서 앞의 글자를 정확히 하나만 지웁니다.
     * 음악 기호나 이모지처럼 컴퓨터 내부에서 "두 조각"으로 이루어진 글자를 지울 때,
     * 한 조각만 지워서 나머지가 깨진 글자(□)로 보이는 문제를 막아줍니다.
     */
    private fun deleteOneCharacter(ic: android.view.inputmethod.InputConnection) {
        val before = ic.getTextBeforeCursor(2, 0)
        if (before != null && before.length >= 2 &&
            Character.isSurrogatePair(before[before.length - 2], before[before.length - 1])
        ) {
            ic.deleteSurroundingText(2, 0)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    /**
     * 커서를 옮깁니다. 좌우는 "지금 커서가 정확히 어디 있는지" 직접 물어보고 그 자리를 새로 지정하는
     * 방식(setSelection)을 써서, 화면에 보이는 위치와 실제로 글자가 들어갈 위치가 어긋나지 않게 합니다.
     * (예전처럼 방향키 신호만 보내면, 일부 앱에서는 화면 커서는 움직여 보여도 실제 입력 위치가
     * 안 따라가는 경우가 있었어요.) 위아래 줄 이동은 좌우처럼 계산하기 어려워서 방향키 신호를 씁니다.
     */
    private fun moveCursor(ic: android.view.inputmethod.InputConnection, direction: String?) {
        if (direction == "LEFT" || direction == "RIGHT") {
            val extracted = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
            if (extracted != null) {
                val pos = if (direction == "LEFT") {
                    (extracted.selectionStart - 1).coerceAtLeast(0)
                } else {
                    extracted.selectionEnd + 1
                }
                ic.setSelection(pos, pos)
                return
            }
        }
        val keyCode = when (direction) {
            "LEFT" -> android.view.KeyEvent.KEYCODE_DPAD_LEFT
            "RIGHT" -> android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            "UP" -> android.view.KeyEvent.KEYCODE_DPAD_UP
            "DOWN" -> android.view.KeyEvent.KEYCODE_DPAD_DOWN
            else -> null
        } ?: return
        val now = android.os.SystemClock.uptimeMillis()
        ic.sendKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, keyCode, 0))
        ic.sendKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_UP, keyCode, 0))
    }

    // ---------- 고정 클립보드/이모지 행 (삭제 불가, 항상 맨 위에 있음) ----------

    private fun buildClipboardHeaderRow(): LinearLayout {
        clipboardToggleButton = Button(this).apply {
            text = "📋 클립보드"
            setOnClickListener {
                if (isClipboardOpen) {
                    closeClipboardStrip()
                } else {
                    closeEmojiPanel()
                    openClipboardStrip()
                }
            }
        }
        emojiToggleButton = Button(this).apply {
            text = "😀 이모지"
            setOnClickListener {
                if (isEmojiOpen) {
                    closeEmojiPanel()
                } else {
                    closeClipboardStrip()
                    openEmojiPanel()
                }
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            addView(
                clipboardToggleButton,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(
                emojiToggleButton,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
    }

    // ---------- 클립보드 띠(strip) ----------
    // 자판 전체를 가리지 않고, 자판 위에 얇은 띠로 붙어서 나옵니다.

    private fun buildClipboardStrip(): HorizontalScrollView {
        clipboardStripContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(android.graphics.Color.parseColor("#EDEFF2"))
        }
        return HorizontalScrollView(this).apply {
            addView(clipboardStripContainer)
        }
    }

    private fun refreshClipboardStrip() {
        clipboardStripContainer.removeAllViews()
        clipboardStripContainer.addView(Button(this).apply {
            text = "닫기"
            setOnClickListener { closeClipboardStrip() }
        })
        val items = ClipboardStore.getHistory(this)
        if (items.isEmpty()) {
            clipboardStripContainer.addView(TextView(this).apply {
                text = "  복사한 내용이 없어요  "
                setPadding(16, 0, 16, 0)
            })
            return
        }
        items.forEach { text ->
            val preview = if (text.length > 16) text.take(16) + "…" else text
            val isSelected = clipboardMoveSource == text
            clipboardStripContainer.addView(Button(this).apply {
                this.text = if (isSelected) "▶ $preview" else preview
                setOnClickListener { onClipboardChipTapped(text) }
                setOnLongClickListener {
                    clipboardMoveSource = text
                    refreshClipboardStrip()
                    true
                }
            })
        }
        clipboardStripContainer.addView(Button(this).apply {
            text = "전체 지우기"
            setOnClickListener {
                ClipboardStore.clear(this@KeyboardIME)
                clipboardMoveSource = null
                refreshClipboardStrip()
            }
        })
    }

    /** 클립보드 칩을 탭했을 때: 이동 모드면 그 자리로 순서 이동, 아니면 바로 입력합니다. */
    private fun onClipboardChipTapped(text: String) {
        val source = clipboardMoveSource
        if (source != null) {
            if (source == text) {
                // 같은 칩을 다시 탭하면 이동 취소
                clipboardMoveSource = null
                refreshClipboardStrip()
                return
            }
            val items = ClipboardStore.getHistory(this).toMutableList()
            val fromIndex = items.indexOf(source)
            if (fromIndex == -1) {
                clipboardMoveSource = null
                refreshClipboardStrip()
                return
            }
            items.removeAt(fromIndex)
            var targetIndex = items.indexOf(text)
            if (targetIndex == -1) targetIndex = items.size
            items.add(targetIndex, source)
            ClipboardStore.reorder(this, items)
            clipboardMoveSource = null
            refreshClipboardStrip()
            return
        }
        currentInputConnection?.commitText(text, 1)
        closeClipboardStrip()
    }

    private fun openClipboardStrip() {
        refreshClipboardStrip()
        clipboardStripScroll.visibility = View.VISIBLE
        isClipboardOpen = true
    }

    private fun closeClipboardStrip() {
        if (!::clipboardStripScroll.isInitialized) return
        clipboardStripScroll.visibility = View.GONE
        isClipboardOpen = false
    }

    // ---------- 이모지 패널 ----------
    // 클립보드처럼 자판 위에 붙었다 열렸다 하는 패널입니다.
    // 이모지 목록은 "언어"와 똑같은 방식으로 저장/편집돼서, 커스터마이징 화면에서 직접 바꿀 수 있어요.
    // 삼성 키보드처럼 카테고리별로 여러 페이지로 나뉘어 있습니다.

    private var emojiCategoryIndex = 0

    private fun buildEmojiPanel(): ScrollView {
        emojiPanelContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(android.graphics.Color.parseColor("#EDEFF2"))
        }
        return ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 620)
            addView(emojiPanelContainer)
        }
    }

    private fun refreshEmojiPanel() {
        emojiPanelContainer.removeAllViews()

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(Button(this).apply {
            text = "닫기"
            setOnClickListener { closeEmojiPanel() }
        })
        emojiPanelContainer.addView(header)

        val tabScroll = HorizontalScrollView(this)
        val tabContainer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        LayoutStore.emojiCategories.forEachIndexed { i, (_, label) ->
            tabContainer.addView(Button(this).apply {
                text = if (i == emojiCategoryIndex) "▶ $label" else label
                setOnClickListener {
                    emojiCategoryIndex = i
                    refreshEmojiPanel()
                }
            })
        }
        tabScroll.addView(tabContainer)
        emojiPanelContainer.addView(tabScroll)

        val categoryCode = LayoutStore.emojiCategories[emojiCategoryIndex].first
        val emojiLayout = LayoutStore.loadLayout(this, categoryCode)
        emojiLayout.rows.forEach { keyRow ->
            val rowView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            keyRow.forEach { key ->
                rowView.addView(Button(this).apply {
                    text = key.label
                    textSize = 20f
                    // 그냥 글자를 넣는 게 아니라, 자판이랑 똑같은 처리 로직을 그대로 태웁니다.
                    // (이렇게 해야 백스페이스/스페이스 같은 기능 키를 이모지 화면에 넣어도 제대로 동작해요.)
                    setOnClickListener { handleKey(key) }
                })
            }
            emojiPanelContainer.addView(rowView)
        }
    }

    private fun openEmojiPanel() {
        refreshEmojiPanel()
        emojiPanelScroll.visibility = View.VISIBLE
        isEmojiOpen = true
    }

    private fun closeEmojiPanel() {
        if (!::emojiPanelScroll.isInitialized) return
        emojiPanelScroll.visibility = View.GONE
        isEmojiOpen = false
    }
}
