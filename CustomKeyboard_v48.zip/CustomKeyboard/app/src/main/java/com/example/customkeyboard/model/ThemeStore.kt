package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ThemeStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_THEME = "keyboard_theme"

    fun load(context: Context): KeyboardTheme {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_THEME, null) ?: return KeyboardTheme()
        return try {
            fromJson(json)
        } catch (e: Exception) {
            KeyboardTheme()
        }
    }

    fun save(context: Context, theme: KeyboardTheme) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_THEME, toJson(theme)).apply()
    }

    fun reset(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_THEME).apply()
    }

    private fun toJson(theme: KeyboardTheme): String {
        val root = JSONObject()
        root.put("backgroundType", theme.backgroundType.name)
        root.put("backgroundColor", theme.backgroundColor)
        val gradArr = JSONArray()
        theme.gradientColors.forEach { gradArr.put(it) }
        root.put("gradientColors", gradArr)
        root.put("gradientDirection", theme.gradientDirection.name)
        root.put("backgroundImageUri", theme.backgroundImageUri ?: "")
        root.put("keyColor", theme.keyColor)
        root.put("specialKeyColor", theme.specialKeyColor)
        root.put("textColor", theme.textColor)
        root.put("keySizeScale", theme.keySizeScale.toDouble())
        root.put("keyGapScale", theme.keyGapScale.toDouble())
        root.put("borderEnabled", theme.borderEnabled)
        root.put("borderType", theme.borderType.name)
        root.put("borderColor", theme.borderColor)
        val borderGradArr = JSONArray()
        theme.borderGradientColors.forEach { borderGradArr.put(it) }
        root.put("borderGradientColors", borderGradArr)
        root.put("borderGradientDirection", theme.borderGradientDirection.name)
        root.put("borderWidth", theme.borderWidth.toDouble())
        root.put("keyBorderEnabled", theme.keyBorderEnabled)
        root.put("keyBorderType", theme.keyBorderType.name)
        root.put("keyBorderColor", theme.keyBorderColor)
        val keyBorderGradArr = JSONArray()
        theme.keyBorderGradientColors.forEach { keyBorderGradArr.put(it) }
        root.put("keyBorderGradientColors", keyBorderGradArr)
        root.put("keyBorderGradientDirection", theme.keyBorderGradientDirection.name)
        root.put("keyBorderWidth", theme.keyBorderWidth.toDouble())
        root.put("fontFamily", theme.fontFamily)
        root.put("customFontUri", theme.customFontUri ?: "")
        root.put("showKeyPreview", theme.showKeyPreview)
        return root.toString()
    }

    private fun fromJson(json: String): KeyboardTheme {
        val root = JSONObject(json)
        val gradArr = root.optJSONArray("gradientColors")
        val gradColors = mutableListOf<Int>()
        if (gradArr != null) {
            for (i in 0 until gradArr.length()) gradColors.add(gradArr.getInt(i))
        }
        val borderGradArr = root.optJSONArray("borderGradientColors")
        val borderGradColors = mutableListOf<Int>()
        if (borderGradArr != null) {
            for (i in 0 until borderGradArr.length()) borderGradColors.add(borderGradArr.getInt(i))
        }
        val keyBorderGradArr = root.optJSONArray("keyBorderGradientColors")
        val keyBorderGradColors = mutableListOf<Int>()
        if (keyBorderGradArr != null) {
            for (i in 0 until keyBorderGradArr.length()) keyBorderGradColors.add(keyBorderGradArr.getInt(i))
        }
        val imageUri = root.optString("backgroundImageUri", "")
        return KeyboardTheme(
            backgroundType = BackgroundType.valueOf(root.optString("backgroundType", "SOLID")),
            backgroundColor = root.optInt("backgroundColor", 0xFFEDEFF2.toInt()),
            gradientColors = if (gradColors.isNotEmpty()) gradColors else listOf(0xFFEDEFF2.toInt(), 0xFFC9D6E3.toInt()),
            gradientDirection = GradientDirection.valueOf(root.optString("gradientDirection", "TOP_TO_BOTTOM")),
            backgroundImageUri = if (imageUri.isEmpty()) null else imageUri,
            keyColor = root.optInt("keyColor", 0xFFFFFFFF.toInt()),
            specialKeyColor = root.optInt("specialKeyColor", 0xFFD8DCE0.toInt()),
            textColor = root.optInt("textColor", 0xFF1A1A1A.toInt()),
            keySizeScale = root.optDouble("keySizeScale", 1.0).toFloat(),
            keyGapScale = root.optDouble("keyGapScale", 1.0).toFloat(),
            borderEnabled = root.optBoolean("borderEnabled", false),
            borderType = BackgroundType.valueOf(root.optString("borderType", "SOLID")),
            borderColor = root.optInt("borderColor", 0xFFB9C2CC.toInt()),
            borderGradientColors = if (borderGradColors.isNotEmpty()) borderGradColors else listOf(0xFF4C7CF0.toInt(), 0xFFB197FC.toInt()),
            borderGradientDirection = GradientDirection.valueOf(root.optString("borderGradientDirection", "LEFT_TO_RIGHT")),
            borderWidth = root.optDouble("borderWidth", 8.0).toFloat(),
            keyBorderEnabled = root.optBoolean("keyBorderEnabled", false),
            keyBorderType = BackgroundType.valueOf(root.optString("keyBorderType", "SOLID")),
            keyBorderColor = root.optInt("keyBorderColor", 0xFFB9C2CC.toInt()),
            keyBorderGradientColors = if (keyBorderGradColors.isNotEmpty()) keyBorderGradColors else listOf(0xFF4C7CF0.toInt(), 0xFFB197FC.toInt()),
            keyBorderGradientDirection = GradientDirection.valueOf(root.optString("keyBorderGradientDirection", "LEFT_TO_RIGHT")),
            keyBorderWidth = root.optDouble("keyBorderWidth", 3.0).toFloat(),
            fontFamily = root.optString("fontFamily", "DEFAULT"),
            customFontUri = root.optString("customFontUri", "").let { if (it.isEmpty()) null else it },
            showKeyPreview = root.optBoolean("showKeyPreview", true)
        )
    }
}
