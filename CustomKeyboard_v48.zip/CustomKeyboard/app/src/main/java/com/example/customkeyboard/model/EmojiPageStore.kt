package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 기본으로 들어있는 이모지 카테고리(스마일리, 사람 등) 말고,
 * 사용자가 직접 추가한 이모지 페이지를 관리합니다.
 */
object EmojiPageStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_CUSTOM = "emoji_custom_pages"
    private const val KEY_NAME_OVERRIDES = "emoji_page_name_overrides"

    fun getCustomPages(context: Context): List<Pair<String, String>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CUSTOM, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.getString("code") to o.getString("name")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** 이모지 페이지 이름을 직접 지정한 것들 (기본 카테고리든 사용자가 만든 페이지든 다 바꿀 수 있어요). */
    fun getNameOverrides(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_NAME_OVERRIDES, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(json)
            val map = mutableMapOf<String, String>()
            obj.keys().forEach { k -> map[k] = obj.getString(k) }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /** 이모지 페이지 이름을 바꿉니다. 빈 문자열을 주면 원래 이름으로 되돌립니다. */
    fun setDisplayName(context: Context, code: String, name: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = getNameOverrides(context).toMutableMap()
        if (name.isBlank()) current.remove(code) else current[code] = name
        val obj = JSONObject()
        current.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit().putString(KEY_NAME_OVERRIDES, obj.toString()).apply()
    }

    /** 바꾼 이름이 있으면 그 이름을, 없으면 기본 이름을 돌려줍니다. */
    fun displayNameFor(context: Context, code: String, defaultName: String): String =
        getNameOverrides(context)[code] ?: defaultName

    /** 새 이모지 페이지를 추가하고, 새로 만든 페이지의 (코드, 이름)을 돌려줍니다. 처음엔 빈 페이지로 시작해요. */
    fun addPage(context: Context, displayName: String): Pair<String, String> {
        val code = "emoji_custom_${System.currentTimeMillis()}"
        val current = getCustomPages(context).toMutableList()
        current.add(code to displayName)
        save(context, current)
        return code to displayName
    }

    /** 사용자가 만든 이모지 페이지를 완전히 삭제합니다. (기본 카테고리는 삭제할 수 없어요.) */
    fun removePage(context: Context, code: String) {
        val current = getCustomPages(context).filter { it.first != code }
        save(context, current)
        LayoutStore.resetLayout(context, code)
    }

    private fun save(context: Context, pages: List<Pair<String, String>>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        pages.forEach {
            val o = JSONObject()
            o.put("code", it.first)
            o.put("name", it.second)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }
}
