package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 언어별 키보드 레이아웃을 저장/불러오기.
 * 언어 코드(예: "ko", "en")마다 따로 저장됩니다.
 */
object LayoutStore {

    private const val PREFS = "keyboard_prefs"

    fun loadLayout(context: Context, code: String): KeyboardLayout {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(keyFor(code), null)
        return if (json != null) importJson(json) else defaultLayout(code)
    }

    fun saveLayout(context: Context, code: String, layout: KeyboardLayout) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(keyFor(code), exportJson(layout)).apply()
    }

    fun resetLayout(context: Context, code: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().remove(keyFor(code)).apply()
    }

    private fun keyFor(code: String) = "layout_$code"

    fun defaultLayout(code: String): KeyboardLayout = when {
        code == "ko" -> defaultKoreanLayout()
        code == "ko_cheonjiin" -> defaultCheonjiinLayout()
        code == "vi" -> defaultVietnameseLayout()
        code == "symbols" -> defaultSymbolsLayout()
        code == "zalgo" -> defaultZalgoLayout()
        code.startsWith("emoji") -> defaultEmojiCategoryLayout(code)
        code.startsWith("symbols") -> defaultSymbolsExtraPageLayout(code)
        else -> defaultLettersLayout()
    }

    fun defaultSymbolsLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            row("@", "#", "$", "%", "&", "*", "-", "+", "(", ")"),
            mutableListOf(
                KeyDef("=", popup = listOf("\\", "<")),
                KeyDef("!"),
                KeyDef("\""),
                KeyDef("'"),
                KeyDef(":"),
                KeyDef(";"),
                KeyDef("/"),
                KeyDef("?"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            mutableListOf(
                KeyDef("◀", KeyType.CURSOR_MOVE, mark = "LEFT"),
                KeyDef("▲", KeyType.CURSOR_MOVE, mark = "UP"),
                KeyDef("▼", KeyType.CURSOR_MOVE, mark = "DOWN"),
                KeyDef("▶", KeyType.CURSOR_MOVE, mark = "RIGHT"),
                KeyDef("◀이전", KeyType.SYMBOLS_PAGE_SWITCH, 1.3f, mark = "PREV"),
                KeyDef("다음▶", KeyType.SYMBOLS_PAGE_SWITCH, 1.3f, mark = "NEXT")
            ),
            bottomRow("ABC")
        )
        return KeyboardLayout("symbols", rows)
    }

    /** "symbols"가 아닌 추가 특수문자 페이지의 기본(빈) 틀입니다. 자유롭게 키를 채워 넣으면 돼요. */
    fun defaultSymbolsExtraPageLayout(code: String): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("◀이전", KeyType.SYMBOLS_PAGE_SWITCH, 1.3f, mark = "PREV"),
                KeyDef("다음▶", KeyType.SYMBOLS_PAGE_SWITCH, 1.3f, mark = "NEXT"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("ABC")
        )
        return KeyboardLayout(code, rows)
    }

    fun defaultLettersLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("q"), KeyDef("w"),
                KeyDef("e", popup = listOf("é", "è", "ê", "ë")),
                KeyDef("r"), KeyDef("t"), KeyDef("y"),
                KeyDef("u", popup = listOf("ú", "ù", "ü")),
                KeyDef("i", popup = listOf("í", "ì", "î")),
                KeyDef("o", popup = listOf("ó", "ò", "ö")),
                KeyDef("p")
            ),
            mutableListOf(
                KeyDef("a", popup = listOf("á", "à", "â", "ä")),
                KeyDef("s", popup = listOf("ß")),
                KeyDef("d"), KeyDef("f"), KeyDef("g"), KeyDef("h"),
                KeyDef("j"), KeyDef("k"), KeyDef("l")
            ),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("z"), KeyDef("x"),
                KeyDef("c", popup = listOf("ç")),
                KeyDef("v"), KeyDef("b"),
                KeyDef("n", popup = listOf("ñ")),
                KeyDef("m"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("en", rows)
    }

    fun defaultKoreanLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("ㅂ", popup = listOf("ㅃ")),
                KeyDef("ㅈ", popup = listOf("ㅉ")),
                KeyDef("ㄷ", popup = listOf("ㄸ")),
                KeyDef("ㄱ", popup = listOf("ㄲ")),
                KeyDef("ㅅ", popup = listOf("ㅆ")),
                KeyDef("ㅛ"), KeyDef("ㅕ"), KeyDef("ㅑ"),
                KeyDef("ㅐ", popup = listOf("ㅒ")),
                KeyDef("ㅔ", popup = listOf("ㅖ"))
            ),
            row("ㅁ", "ㄴ", "ㅇ", "ㄹ", "ㅎ", "ㅗ", "ㅓ", "ㅏ", "ㅣ"),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("ㅋ"), KeyDef("ㅌ"), KeyDef("ㅊ"), KeyDef("ㅍ"),
                KeyDef("ㅠ"), KeyDef("ㅜ"), KeyDef("ㅡ"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("ko", rows)
    }

    fun defaultCheonjiinLayout(): KeyboardLayout {
        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            mutableListOf(
                KeyDef("ㄱㅋㄲ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄱ", "ㅋ", "ㄲ")),
                KeyDef("ㄴㄹ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄴ", "ㄹ")),
                KeyDef("ㄷㅌㄸ", KeyType.CHEONJIIN_CONS, popup = listOf("ㄷ", "ㅌ", "ㄸ")),
                KeyDef("ㅁㅇ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅁ", "ㅇ"))
            ),
            mutableListOf(
                KeyDef("ㅂㅍㅃ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅂ", "ㅍ", "ㅃ")),
                KeyDef("ㅅㅎㅆ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅅ", "ㅎ", "ㅆ")),
                KeyDef("ㅈㅊㅉ", KeyType.CHEONJIIN_CONS, popup = listOf("ㅈ", "ㅊ", "ㅉ")),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            mutableListOf(
                KeyDef("ㅣ", KeyType.CHEONJIIN_STROKE),
                KeyDef("ㆍ", KeyType.CHEONJIIN_STROKE),
                KeyDef("ㅡ", KeyType.CHEONJIIN_STROKE)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("ko_cheonjiin", rows)
    }

    fun defaultVietnameseLayout(): KeyboardLayout {
        val rows = mutableListOf(
            mutableListOf(
                KeyDef("ă"), KeyDef("â"), KeyDef("ê"), KeyDef("ô"), KeyDef("ư"), KeyDef("ơ"),
                KeyDef("\u0301", KeyType.DIACRITIC, mark = "\u0301"), // sắc
                KeyDef("\u0300", KeyType.DIACRITIC, mark = "\u0300"), // huyền
                KeyDef("\u0309", KeyType.DIACRITIC, mark = "\u0309"), // hỏi
                KeyDef("\u0303", KeyType.DIACRITIC, mark = "\u0303"), // ngã
                KeyDef(".", KeyType.DIACRITIC, mark = "\u0323")       // nặng
            ),
            row("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            mutableListOf(
                KeyDef("a"), KeyDef("s"),
                KeyDef("d", popup = listOf("đ")),
                KeyDef("f"), KeyDef("g"), KeyDef("h"), KeyDef("j"), KeyDef("k"), KeyDef("l")
            ),
            mutableListOf(
                KeyDef("⇧", KeyType.SHIFT, 1.5f),
                KeyDef("z"), KeyDef("x"), KeyDef("c"), KeyDef("v"), KeyDef("b"), KeyDef("n"), KeyDef("m"),
                KeyDef("⌫", KeyType.BACKSPACE, 1.5f)
            ),
            bottomRow("123")
        )
        return KeyboardLayout("vi", rows)
    }

    // 유니코드 "결합 문자(Combining Marks)" 관련 블록 전체를 모았어요.
    // U+0300~U+036F (Combining Diacritical Marks, 112개)
    // U+1DC0~U+1DFF (Combining Diacritical Marks Supplement, 64개)
    // U+20D0~U+20FF (Combining Diacritical Marks for Symbols, 48개)
    // U+FE20~U+FE2F (Combining Half Marks, 16개)
    // 다 합쳐서 240개, 진짜 Zalgo 텍스트에 쓰이는 유니코드 범위예요.
    // 앱이 시작될 때 딱 한 번만 배열로 만들어두고, 이후에는 인덱스로만 꺼내 씁니다 (매번 새로 안 만듦).
    private val zalgoMarks: CharArray = (
        (0x0300..0x036F) +
            (0x1DC0..0x1DFF) +
            (0x20D0..0x20FF) +
            (0xFE20..0xFE2F)
        ).map { it.toChar() }.toCharArray()

    private val zalgoLetters: CharArray = ('a'..'z').toList().toCharArray()

    fun defaultZalgoLayout(): KeyboardLayout {
        val letterCount = zalgoLetters.size
        // 240개 결합 문자를 26개 글자에 골고루 나눠서, 어떤 글자를 길게 눌러도 다른 조합이 나오게 합니다.
        // (전부 다 겹치지 않게 나누기 때문에, 26개 글자를 다 훑어보면 240개를 전부 만날 수 있어요.)
        val popupBuckets = Array(letterCount) { mutableListOf<String>() }
        for (i in zalgoMarks.indices) {
            popupBuckets[i % letterCount].add(zalgoMarks[i].toString())
        }

        var idx = 0
        val letterRow1 = mutableListOf<KeyDef>()
        repeat(9) { letterRow1.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        val letterRow2 = mutableListOf<KeyDef>()
        repeat(9) { letterRow2.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        val letterRow3 = mutableListOf<KeyDef>()
        repeat(8) { letterRow3.add(KeyDef(zalgoLetters[idx].toString(), popup = popupBuckets[idx])); idx++ }
        letterRow3.add(KeyDef("⌫", KeyType.BACKSPACE, 1.5f))

        // 자주 쓰이는 결합 문자는 길게 누르지 않고 바로 탭할 수 있게 두 줄 더 넣어둡니다.
        val quickRow1 = (0 until 11).map { KeyDef(zalgoMarks[it].toString()) }.toMutableList()
        val quickRow2 = (11 until 22).map { KeyDef(zalgoMarks[it].toString()) }.toMutableList()

        val rows = mutableListOf(
            row("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            letterRow1,
            letterRow2,
            letterRow3,
            quickRow1,
            quickRow2,
            bottomRow("123")
        )
        return KeyboardLayout("zalgo", rows)
    }

    /** 이모지 카테고리 목록 (코드, 화면에 보일 이름). 삼성 키보드처럼 카테고리별로 페이지가 나뉩니다. */
    val emojiCategories: List<Pair<String, String>> = listOf(
        "emoji_smileys" to "😀 스마일리",
        "emoji_people" to "🧑 사람",
        "emoji_animals" to "🐶 동물・자연",
        "emoji_food" to "🍔 음식・음료",
        "emoji_activity" to "⚽ 활동",
        "emoji_travel" to "✈️ 여행・장소",
        "emoji_objects" to "💡 사물",
        "emoji_symbols" to "❤️ 기호",
        "emoji_flags" to "🏳️ 국기"
    )

    private val emojiSmileys = listOf(
        "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃",
        "😉", "😊", "😇", "🥰", "😍", "🤩", "😘", "😗", "☺️", "😚",
        "😙", "🥲", "😋", "😛", "😜", "🤪", "😝", "🤑", "🤗", "🤭",
        "🤫", "🤔", "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄",
        "😬", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕",
        "🤢", "🤮", "🤧", "🥵", "🥶", "🥴", "😵", "🤯", "🤠", "🥳",
        "🥸", "😎", "🤓", "🧐", "😕", "😟", "🙁", "☹️", "😮", "😯",
        "😲", "😳", "🥺", "😦", "😧", "😨", "😰", "😥", "😢", "😭",
        "😱", "😖", "😣", "😞", "😓", "😩", "😫", "🥱", "😤", "😡",
        "😠", "🤬", "😈", "👿", "💀", "☠️", "💩", "🤡", "👹", "👺",
        "👻", "👽", "👾", "🤖", "😺", "😸", "😹", "😻", "😼", "😽",
        "🙀", "😿", "😾"
    )

    private val emojiPeople = listOf(
        "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞",
        "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍",
        "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝",
        "🙏", "✍️", "💅", "🤳", "💪", "🦾", "🦵", "🦿", "🦶", "👂",
        "🦻", "👃", "🧠", "🦷", "🦴", "👀", "👁️", "👅", "👄", "👶",
        "🧒", "👦", "👧", "🧑", "👨", "👩", "🧓", "👴", "👵", "🙍",
        "🙎", "🙅", "🙆", "💁", "🙋", "🧏", "🙇", "🤦", "🤷", "👮",
        "🕵️", "💂", "👷", "🤴", "👸", "👳", "👲", "🧕", "🤵", "👰",
        "🤰", "🤱", "👼", "🎅", "🤶", "🦸", "🦹", "🧙", "🧚", "🧛",
        "🧜", "🧝", "🧞", "🧟", "💆", "💇", "🚶", "🧍", "🧎", "👯",
        "🧖", "👭", "👫", "👬", "💏", "💑", "👪"
    )

    private val emojiAnimals = listOf(
        "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯",
        "🦁", "🐮", "🐷", "🐽", "🐸", "🐵", "🙈", "🙉", "🙊", "🐒",
        "🐔", "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇",
        "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜",
        "🦟", "🕷️", "🕸️", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙",
        "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🐋",
        "🦈", "🐊", "🐅", "🐆", "🦓", "🦍", "🦧", "🐘", "🦛", "🦏",
        "🐪", "🐫", "🦒", "🦘", "🐃", "🐂", "🐄", "🐎", "🐖", "🐏",
        "🐑", "🦙", "🐐", "🦌", "🐕", "🐩", "🐈", "🐓", "🦃", "🦚",
        "🦜", "🦢", "🦩", "🕊️", "🐇", "🦝", "🦨", "🦡", "🦫", "🦦",
        "🐁", "🐀", "🐿️", "🦔", "🐉", "🐲", "🌵", "🎄", "🌲", "🌳",
        "🌴", "🌱", "🌿", "☘️", "🍀", "🍃", "🍂", "🍁", "🍄", "🌾",
        "💐", "🌷", "🌹", "🥀", "🌺", "🌸", "🌼", "🌻", "🌞", "🌝",
        "🌛", "🌜", "🌚", "🌕", "🌖", "🌗", "🌘", "🌑", "🌒", "🌓",
        "🌔", "🌙", "🌎", "🌍", "🌏", "💫", "⭐", "🌟", "✨", "⚡",
        "🔥", "🌈", "☀️", "⛅", "☁️", "🌧️", "⛈️", "❄️", "☃️", "🌊"
    )

    private val emojiFood = listOf(
        "🍇", "🍈", "🍉", "🍊", "🍋", "🍌", "🍍", "🥭", "🍎", "🍏",
        "🍐", "🍑", "🍒", "🍓", "🫐", "🥝", "🍅", "🥥", "🥑", "🍆",
        "🥔", "🥕", "🌽", "🌶️", "🥒", "🥬", "🥦", "🧄", "🧅", "🍄",
        "🥜", "🌰", "🍞", "🥐", "🥖", "🥨", "🥯", "🥞", "🧇", "🧀",
        "🍖", "🍗", "🥩", "🥓", "🍔", "🍟", "🍕", "🌭", "🥪", "🌮",
        "🌯", "🥙", "🧆", "🥚", "🍳", "🥘", "🍲", "🥣", "🥗", "🍿",
        "🧈", "🧂", "🥫", "🍱", "🍘", "🍙", "🍚", "🍛", "🍜", "🍝",
        "🍠", "🍢", "🍣", "🍤", "🍥", "🥮", "🍡", "🥟", "🥠", "🥡",
        "🦪", "🍦", "🍧", "🍨", "🍩", "🍪", "🎂", "🍰", "🧁", "🥧",
        "🍫", "🍬", "🍭", "🍮", "🍯", "🍼", "🥛", "☕", "🍵", "🍶",
        "🍾", "🍷", "🍸", "🍹", "🍺", "🍻", "🥂", "🥃", "🥤", "🧋",
        "🧃", "🧉", "🧊", "🥢", "🍽️", "🍴", "🥄"
    )

    private val emojiActivity = listOf(
        "⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱",
        "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🥅", "⛳", "🪁",
        "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛼", "🛷", "⛸️",
        "🥌", "🎿", "⛷️", "🏂", "🪂", "🏋️", "🤼", "🤸", "⛹️", "🤺",
        "🤾", "🏌️", "🏇", "🧘", "🏄", "🏊", "🤽", "🚣", "🧗", "🚵",
        "🚴", "🏆", "🥇", "🥈", "🥉", "🏅", "🎖️", "🏵️", "🎗️", "🎫",
        "🎟️", "🎪", "🤹", "🎭", "🩰", "🎨", "🎬", "🎤", "🎧", "🎼",
        "🎹", "🥁", "🪘", "🎷", "🎺", "🪗", "🎸", "🪕", "🎻", "🎲",
        "♟️", "🎯", "🎳", "🎮", "🎰", "🧩"
    )

    private val emojiTravel = listOf(
        "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚐",
        "🚚", "🚛", "🚜", "🛴", "🚲", "🛵", "🏍️", "🛺", "🚨", "🚔",
        "🚍", "🚘", "🚖", "🚡", "🚠", "🚟", "🚃", "🚋", "🚞", "🚝",
        "🚄", "🚅", "🚈", "🚂", "🚆", "🚇", "🚊", "✈️", "🛫", "🛬",
        "🛩️", "💺", "🛰️", "🚀", "🛸", "🚁", "🛶", "⛵", "🚤", "🛥️",
        "🛳️", "⛴️", "🚢", "⚓", "⛽", "🚧", "🚦", "🚥", "🚏", "🗺️",
        "🗿", "🗽", "🗼", "🏰", "🏯", "🎡", "🎢", "🎠", "⛲", "🏖️",
        "🏝️", "🏜️", "🌋", "⛰️", "🏔️", "🗻", "🏕️", "⛺", "🏠", "🏡",
        "🏘️", "🏗️", "🏭", "🏢", "🏬", "🏣", "🏤", "🏥", "🏦", "🏨",
        "🏪", "🏫", "🏩", "💒", "🏛️", "⛪", "🕌", "🕍", "🛕", "⛩️"
    )

    private val emojiObjects = listOf(
        "⌚", "📱", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🕹️", "💽", "💾",
        "💿", "📀", "📷", "📸", "📹", "🎥", "📽️", "📞", "☎️", "📺",
        "📻", "🎙️", "🧭", "⏱️", "⏰", "🕰️", "⌛", "⏳", "📡", "🔋",
        "🔌", "💡", "🔦", "🕯️", "🧯", "💸", "💵", "💴", "💶", "💷",
        "💰", "💳", "💎", "⚖️", "🧰", "🔧", "🔨", "⚒️", "🛠️", "⛏️",
        "🔩", "⚙️", "🧱", "⛓️", "🧲", "🔫", "💣", "🔪", "🗡️", "⚔️",
        "🛡️", "🚬", "⚰️", "🏺", "🔮", "📿", "🔭", "🔬", "💊", "💉",
        "🩸", "🌡️", "🧹", "🧺", "🧻", "🚽", "🚿", "🛁", "🧼", "🪥",
        "🔑", "🗝️", "🚪", "🪑", "🛋️", "🛏️", "🧸", "🖼️", "🪞", "🛍️",
        "🛒", "🎁", "🎈", "🎀", "🎊", "🎉", "✉️", "📩", "📧", "💌",
        "📦", "🏷️", "📜", "📄", "📊", "📈", "📉", "📅", "🗑️", "📁",
        "📂", "📰", "📓", "📔", "📒", "📕", "📗", "📘", "📙", "📚",
        "📖", "🔖", "🔗", "📎", "📐", "📏", "✂️", "🖊️", "🖋️", "✏️",
        "🔍", "🔒", "🔓"
    )

    private val emojiSymbols = listOf(
        "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔",
        "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️",
        "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "☯️", "🛐", "⛎", "♈",
        "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒",
        "♓", "🆔", "⚛️", "☢️", "☣️", "📴", "📳", "🈶", "🈚", "🈸",
        "🈺", "🈷️", "✴️", "🆚", "💮", "🉐", "㊙️", "㊗️", "🈴", "🈵",
        "🈹", "🈲", "🅰️", "🅱️", "🆎", "🆑", "🅾️", "🆘", "❌", "⭕",
        "🛑", "⛔", "📛", "🚫", "💯", "💢", "♨️", "🚷", "🚯", "🚳",
        "🚱", "🔞", "📵", "🚭", "❗", "❕", "❓", "❔", "‼️", "⁉️",
        "⚠️", "🚸", "🔱", "♻️", "✅", "❇️", "✳️", "❎", "🌐", "💠",
        "🌀", "💤", "♿", "🚹", "🚺", "🚼", "🚻", "🚮", "ℹ️", "🔤",
        "🔡", "🔠", "🆖", "🆗", "🆙", "🆒", "🆕", "🆓", "0️⃣", "1️⃣",
        "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "🔢",
        "▶️", "⏸️", "⏭️", "⏮️", "⏩", "⏪", "◀️", "🔼", "🔽", "➡️",
        "⬅️", "⬆️", "⬇️", "↕️", "↔️", "↩️", "↪️", "🔀", "🔁", "🔂",
        "🎵", "🎶", "➕", "➖", "➗", "✖️", "💲", "™️", "©️", "®️",
        "〰️", "➰", "🔚", "🔙", "🔛", "🔝", "🔜", "✔️", "☑️", "🔘",
        "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "⚫", "⚪", "🟤", "🔺",
        "🔻", "🔸", "🔹", "🔶", "🔷", "🔳", "🔲", "▪️", "▫️", "◾",
        "◽", "◼️", "◻️", "🟥", "🟧", "🟨", "🟩", "🟦", "🟪", "⬛",
        "⬜", "🟫"
    )

    private val emojiFlags = listOf(
        "🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🏴‍☠️",
        "🇰🇷", "🇺🇸", "🇯🇵", "🇨🇳", "🇬🇧", "🇫🇷", "🇩🇪", "🇮🇹", "🇪🇸", "🇵🇹",
        "🇷🇺", "🇨🇦", "🇦🇺", "🇧🇷", "🇮🇳", "🇲🇽", "🇮🇩", "🇹🇭", "🇻🇳", "🇵🇭",
        "🇲🇾", "🇸🇬", "🇹🇼", "🇭🇰", "🇲🇴", "🇳🇱", "🇧🇪", "🇨🇭", "🇦🇹", "🇸🇪",
        "🇳🇴", "🇩🇰", "🇫🇮", "🇮🇸", "🇵🇱", "🇬🇷", "🇹🇷", "🇮🇱", "🇸🇦", "🇦🇪",
        "🇶🇦", "🇰🇼", "🇧🇭", "🇴🇲", "🇯🇴", "🇱🇧", "🇮🇶", "🇮🇷", "🇦🇫", "🇪🇬",
        "🇿🇦", "🇳🇬", "🇰🇪", "🇬🇭", "🇪🇹", "🇹🇿", "🇺🇬", "🇿🇼", "🇿🇲", "🇲🇿",
        "🇦🇴", "🇸🇳", "🇨🇮", "🇨🇲", "🇩🇿", "🇹🇳", "🇲🇦", "🇱🇾", "🇸🇩", "🇷🇼",
        "🇦🇷", "🇨🇱", "🇨🇴", "🇵🇪", "🇻🇪", "🇪🇨", "🇺🇾", "🇵🇾", "🇧🇴", "🇨🇺",
        "🇳🇿", "🇮🇪", "🇨🇿", "🇭🇺", "🇷🇴", "🇺🇦", "🇧🇬", "🇭🇷", "🇸🇰", "🇸🇮",
        "🇱🇹", "🇱🇻", "🇪🇪", "🇱🇺", "🇲🇹", "🇨🇾", "🇲🇨", "🇸🇲", "🇻🇦", "🇦🇩",
        "🇧🇩", "🇵🇰", "🇱🇰", "🇳🇵", "🇲🇲", "🇰🇭", "🇱🇦", "🇧🇳", "🇰🇵", "🇲🇳",
        "🇰🇿", "🇺🇿", "🇬🇪", "🇦🇲", "🇦🇿"
    )

    fun defaultEmojiCategoryLayout(code: String): KeyboardLayout {
        if (code.startsWith("emoji_custom_")) {
            // 사용자가 새로 만든 이모지 페이지는 빈 줄 하나로 시작해서, 직접 채워 넣게 합니다.
            return KeyboardLayout(code, mutableListOf(mutableListOf()))
        }
        val list = when (code) {
            "emoji_smileys" -> emojiSmileys
            "emoji_people" -> emojiPeople
            "emoji_animals" -> emojiAnimals
            "emoji_food" -> emojiFood
            "emoji_activity" -> emojiActivity
            "emoji_travel" -> emojiTravel
            "emoji_objects" -> emojiObjects
            "emoji_symbols" -> emojiSymbols
            "emoji_flags" -> emojiFlags
            else -> emojiSmileys
        }
        val rows = list.chunked(8)
            .map { chunk -> chunk.map { KeyDef(it) }.toMutableList() }
            .toMutableList()
        return KeyboardLayout(code, rows)
    }

    private fun bottomRow(symbolsToggleLabel: String): MutableList<KeyDef> =
        mutableListOf(
            KeyDef(symbolsToggleLabel, KeyType.SYMBOLS_TOGGLE, 1.2f),
            KeyDef("🌐", KeyType.LANG_SWITCH, 1f),
            KeyDef(","),
            KeyDef("스페이스", KeyType.SPACE, 3.5f),
            KeyDef("."),
            KeyDef("이동", KeyType.ENTER, 1.3f)
        )

    private fun row(vararg labels: String): MutableList<KeyDef> =
        labels.map { KeyDef(it) }.toMutableList()

    /** 지금 레이아웃을 텍스트(JSON)로 내보냅니다. 공유하거나 다른 곳에 백업해뒀다가 가져오기로 다시 불러올 수 있어요. */
    fun exportJson(layout: KeyboardLayout): String {
        val root = JSONObject()
        root.put("name", layout.name)
        val rowsArr = JSONArray()
        layout.rows.forEach { r ->
            val rowArr = JSONArray()
            r.forEach { key ->
                val k = JSONObject()
                k.put("label", key.label)
                k.put("type", key.type.name)
                k.put("weight", key.weight.toDouble())
                k.put("mark", key.mark)
                k.put("heightScale", key.heightScale.toDouble())
                k.put("widthScale", key.widthScale.toDouble())
                val popupArr = JSONArray()
                key.popup.forEach { popupArr.put(it) }
                k.put("popup", popupArr)
                rowArr.put(k)
            }
            rowsArr.put(rowArr)
        }
        root.put("rows", rowsArr)
        return root.toString()
    }

    /** 내보내기로 만든 텍스트(JSON)를 다시 레이아웃으로 되돌립니다. 형식이 잘못되면 예외를 던집니다. */
    fun importJson(json: String): KeyboardLayout {
        val root = JSONObject(json)
        val name = root.getString("name")
        val rowsArr = root.getJSONArray("rows")
        val rows = mutableListOf<MutableList<KeyDef>>()
        for (i in 0 until rowsArr.length()) {
            val rowArr = rowsArr.getJSONArray(i)
            val r = mutableListOf<KeyDef>()
            for (j in 0 until rowArr.length()) {
                val k = rowArr.getJSONObject(j)
                val popupArr = k.optJSONArray("popup")
                val popupList = mutableListOf<String>()
                if (popupArr != null) {
                    for (p in 0 until popupArr.length()) popupList.add(popupArr.getString(p))
                }
                r.add(
                    KeyDef(
                        label = k.getString("label"),
                        type = try {
                            KeyType.valueOf(k.optString("type", "NORMAL"))
                        } catch (e: IllegalArgumentException) {
                            KeyType.NORMAL
                        },
                        weight = k.optDouble("weight", 1.0).toFloat(),
                        popup = popupList,
                        mark = k.optString("mark", ""),
                        heightScale = k.optDouble("heightScale", 1.0).toFloat(),
                        widthScale = k.optDouble("widthScale", 1.0).toFloat()
                    )
                )
            }
            rows.add(r)
        }
        return KeyboardLayout(name, rows)
    }
}
