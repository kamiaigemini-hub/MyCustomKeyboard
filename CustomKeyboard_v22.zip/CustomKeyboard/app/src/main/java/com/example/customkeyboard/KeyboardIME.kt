package com.example.customkeyboard

import android.content.ClipboardManager
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.customkeyboard.model.ClipboardStore
import com.example.customkeyboard.model.KeyDef
import com.example.customkeyboard.model.KeyType
import com.example.customkeyboard.model.KeyboardLayout
import com.example.customkeyboard.model.LanguageDef
import com.example.customkeyboard.model.LanguageStore
import com.example.customkeyboard.model.LayoutStore
import com.example.customkeyboard.model.ThemeStore
import com.example.customkeyboard.text.CheonjiinProcessor
import com.example.customkeyboard.text.DiacriticComposer
import com.example.customkeyboard.text.HangulComposer
import com.example.customkeyboard.view.KeyboardView

/**
 * 실제 키보드 서비스. 시스템이 텍스트 입력창에 포커스가 잡히면
 * 이 서비스가 onCreateInputView()로 만든 뷰를 화면 하단에 띄웁니다.
 */
class KeyboardIME : InputMethodService() {

    private enum class ShiftState { OFF, ONCE, CAPS_LOCK }

    private lateinit var container: LinearLayout
    private lateinit var keyboardView: KeyboardView
    private lateinit var clipboardHeaderRow: LinearLayout
    private lateinit var clipboardToggleButton: Button
    private lateinit var clipboardStripScroll: HorizontalScrollView
    private lateinit var clipboardStripContainer: LinearLayout
    private lateinit var symbolsLayout: KeyboardLayout
    private lateinit var currentLayout: KeyboardLayout
    private var currentLangCode: String = "ko"
    private var currentLang: LanguageDef = LanguageStore.ALL[0]
    private var isSymbolsMode = false
    private var isClipboardOpen = false
    private var clipboardMoveSource: String? = null
    private var shiftState = ShiftState.OFF

    private val hangulComposer by lazy { HangulComposer { currentInputConnection } }
    private val cheonjiinProcessor by lazy { CheonjiinProcessor(hangulComposer) }
    private val diacriticComposer by lazy { DiacriticComposer { currentInputConnection } }

    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = cm?.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) {
                ClipboardStore.addEntry(this, text)
                if (isClipboardOpen) refreshClipboardStrip()
            }
        }
    }

    override fun onCreateInputView(): View {
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keyboardView = KeyboardView(this)
        keyboardView.onKeyListener = { key -> handleKey(key) }

        clipboardHeaderRow = buildClipboardHeaderRow()
        clipboardStripScroll = buildClipboardStrip()
        clipboardStripScroll.visibility = View.GONE
        container.addView(clipboardHeaderRow)
        container.addView(clipboardStripScroll)
        container.addView(keyboardView)

        loadCurrentLanguage()

        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.addPrimaryClipChangedListener(clipboardListener)

        return container
    }

    override fun onDestroy() {
        super.onDestroy()
        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.removePrimaryClipChangedListener(clipboardListener)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        isSymbolsMode = false
        setShiftState(ShiftState.OFF)
        closeClipboardStrip()
        loadCurrentLanguage()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        loadCurrentLanguage()
    }

    private fun loadCurrentLanguage() {
        val installed = LanguageStore.installedLanguages(this)
        if (installed.none { it.code == currentLangCode }) {
            currentLangCode = installed.firstOrNull()?.code ?: "en"
        }
        currentLang = LanguageStore.defByCode(this, currentLangCode)
        currentLayout = LayoutStore.loadLayout(this, currentLangCode)
        symbolsLayout = LayoutStore.loadLayout(this, "symbols")
        val theme = ThemeStore.load(this)
        keyboardView.applyTheme(theme)
        keyboardView.setLayout(if (isSymbolsMode) symbolsLayout else currentLayout)
        clipboardToggleButton.setBackgroundColor(theme.specialKeyColor)
        clipboardToggleButton.setTextColor(theme.textColor)
        clipboardHeaderRow.setBackgroundColor(theme.backgroundColor)
    }

    private fun setShiftState(state: ShiftState) {
        shiftState = state
        keyboardView.setShiftState(state != ShiftState.OFF, state == ShiftState.CAPS_LOCK)
    }

    private fun handleKey(key: KeyDef) {
        val ic = currentInputConnection ?: return
        // 한 번 키를 누를 때 생기는 여러 단계(지우기+새로 넣기 등)를 한 묶음으로 상대 앱에 전달해서
        // 상대 앱이 매번 다시 그리는 걸 줄여줍니다. (삼성 키보드 등이 쓰는 표준 기법)
        ic.beginBatchEdit()
        try {
            handleKeyInternal(key, ic)
        } finally {
            ic.endBatchEdit()
        }
    }

    private fun handleKeyInternal(key: KeyDef, ic: android.view.inputmethod.InputConnection) {
        val lang = currentLang

        // 백스페이스: 조합 중인 게 있으면 한 조각씩 지웁니다.
        if (key.type == KeyType.BACKSPACE) {
            if (lang.isCheonjiin && cheonjiinProcessor.backspace()) return
            if (lang.isHangul && !lang.isCheonjiin && hangulComposer.backspace()) return
            diacriticComposer.reset()
            deleteOneCharacter(ic)
            return
        }

        // 클립보드 열기/닫기
        if (key.type == KeyType.CLIPBOARD_TOGGLE) {
            if (isClipboardOpen) closeClipboardStrip() else openClipboardStrip()
            return
        }

        // 천지인 자음 키 (같은 키를 반복해서 누르면 ㄱ→ㅋ→ㄲ 순환)
        if (lang.isCheonjiin && key.type == KeyType.CHEONJIIN_CONS) {
            val group = key.popup.mapNotNull { it.firstOrNull() }
            cheonjiinProcessor.pressConsonant(group)
            return
        }

        // 천지인 모음 획 키 (ㅣ, ㆍ, ㅡ를 합쳐서 모음을 만듭니다)
        if (lang.isCheonjiin && key.type == KeyType.CHEONJIIN_STROKE && key.label.isNotEmpty()) {
            cheonjiinProcessor.pressStroke(key.label[0])
            return
        }

        // 조합 키 (모든 언어에서 공통으로 작동: 바로 앞에 친 글자에 합쳐집니다)
        if (key.type == KeyType.DIACRITIC) {
            diacriticComposer.applyDiacritic(key.mark)
            return
        }

        // 일반 한글(2벌식) 모드에서 자음/모음이면 조합 엔진으로 보냅니다.
        if (lang.isHangul && !lang.isCheonjiin && key.type == KeyType.NORMAL && key.label.length == 1 &&
            (HangulComposer.CHO.contains(key.label[0]) || HangulComposer.JUNG.contains(key.label[0]))
        ) {
            hangulComposer.inputJamo(key.label[0])
            return
        }

        // 그 외의 키(숫자, 기호, 스페이스, 엔터 등)를 누르면 조합 중이던 글자를 먼저 확정합니다.
        if (lang.isCheonjiin) cheonjiinProcessor.commitAll()
        else if (lang.isHangul) hangulComposer.commit()
        else if (key.type != KeyType.NORMAL) diacriticComposer.reset()

        when (key.type) {
            KeyType.NORMAL -> {
                val text = if (shiftState != ShiftState.OFF && key.label.length == 1 && key.label[0].isLetter()) {
                    key.label.uppercase()
                } else {
                    key.label
                }
                ic.commitText(text, 1)
                if (shiftState == ShiftState.ONCE) setShiftState(ShiftState.OFF)
                if (text.length == 1) {
                    diacriticComposer.onBaseLetterTyped(text[0])
                } else {
                    diacriticComposer.reset()
                }
            }
            KeyType.SPACE -> ic.commitText(" ", 1)
            KeyType.SHIFT -> {
                // 1번 누르면 다음 한 글자만 대문자, 2번째 누르면 계속 대문자(Caps Lock), 3번째 누르면 다시 소문자.
                val next = when (shiftState) {
                    ShiftState.OFF -> ShiftState.ONCE
                    ShiftState.ONCE -> ShiftState.CAPS_LOCK
                    ShiftState.CAPS_LOCK -> ShiftState.OFF
                }
                setShiftState(next)
            }
            KeyType.ENTER -> {
                val info = currentInputEditorInfo
                if (info != null) {
                    val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
                    if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                        ic.performEditorAction(action)
                    } else {
                        ic.commitText("\n", 1)
                    }
                } else {
                    ic.commitText("\n", 1)
                }
            }
            KeyType.SYMBOLS_TOGGLE -> {
                isSymbolsMode = !isSymbolsMode
                keyboardView.setLayout(if (isSymbolsMode) symbolsLayout else currentLayout)
            }
            KeyType.LANG_SWITCH -> {
                val installed = LanguageStore.installedLanguages(this)
                if (installed.size > 1) {
                    val idx = installed.indexOfFirst { it.code == currentLangCode }
                    val next = installed[(idx + 1) % installed.size]
                    currentLangCode = next.code
                    currentLang = next
                    isSymbolsMode = false
                    setShiftState(ShiftState.OFF)
                    currentLayout = LayoutStore.loadLayout(this, currentLangCode)
                    keyboardView.setLayout(currentLayout)
                }
            }
            else -> { /* 위에서 이미 처리됨 (BACKSPACE, CLIPBOARD_TOGGLE, CHEONJIIN_CONS, CHEONJIIN_STROKE, DIACRITIC) */ }
        }
    }

    /**
     * 커서 앞의 글자를 정확히 하나만 지웁니다.
     * 음악 기호나 이모지처럼 컴퓨터 내부에서 "두 조각"으로 이루어진 글자를 지울 때,
     * 한 조각만 지워서 나머지가 깨진 글자(□)로 보이는 문제를 막아줍니다.
     */
    private fun deleteOneCharacter(ic: android.view.inputmethod.InputConnection) {
        val before = ic.getTextBeforeCursor(2, 0)
        if (before != null && before.length >= 2 &&
            Character.isSurrogatePair(before[before.length - 2], before[before.length - 1])
        ) {
            ic.deleteSurroundingText(2, 0)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    // ---------- 고정 클립보드 행 (삭제 불가, 항상 맨 위에 있음) ----------

    private fun buildClipboardHeaderRow(): LinearLayout {
        clipboardToggleButton = Button(this).apply {
            text = "📋 클립보드"
            setOnClickListener {
                if (isClipboardOpen) closeClipboardStrip() else openClipboardStrip()
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            addView(
                clipboardToggleButton,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            )
        }
    }

    // ---------- 클립보드 띠(strip) ----------
    // 자판 전체를 가리지 않고, 자판 위에 얇은 띠로 붙어서 나옵니다.

    private fun buildClipboardStrip(): HorizontalScrollView {
        clipboardStripContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(android.graphics.Color.parseColor("#EDEFF2"))
        }
        return HorizontalScrollView(this).apply {
            addView(clipboardStripContainer)
        }
    }

    private fun refreshClipboardStrip() {
        clipboardStripContainer.removeAllViews()
        clipboardStripContainer.addView(Button(this).apply {
            text = "닫기"
            setOnClickListener { closeClipboardStrip() }
        })
        val items = ClipboardStore.getHistory(this)
        if (items.isEmpty()) {
            clipboardStripContainer.addView(TextView(this).apply {
                text = "  복사한 내용이 없어요  "
                setPadding(16, 0, 16, 0)
            })
            return
        }
        items.forEach { text ->
            val preview = if (text.length > 16) text.take(16) + "…" else text
            val isSelected = clipboardMoveSource == text
            clipboardStripContainer.addView(Button(this).apply {
                this.text = if (isSelected) "▶ $preview" else preview
                setOnClickListener { onClipboardChipTapped(text) }
                setOnLongClickListener {
                    clipboardMoveSource = text
                    refreshClipboardStrip()
                    true
                }
            })
        }
        clipboardStripContainer.addView(Button(this).apply {
            text = "전체 지우기"
            setOnClickListener {
                ClipboardStore.clear(this@KeyboardIME)
                clipboardMoveSource = null
                refreshClipboardStrip()
            }
        })
    }

    /** 클립보드 칩을 탭했을 때: 이동 모드면 그 자리로 순서 이동, 아니면 바로 입력합니다. */
    private fun onClipboardChipTapped(text: String) {
        val source = clipboardMoveSource
        if (source != null) {
            if (source == text) {
                // 같은 칩을 다시 탭하면 이동 취소
                clipboardMoveSource = null
                refreshClipboardStrip()
                return
            }
            val items = ClipboardStore.getHistory(this).toMutableList()
            val fromIndex = items.indexOf(source)
            if (fromIndex == -1) {
                clipboardMoveSource = null
                refreshClipboardStrip()
                return
            }
            items.removeAt(fromIndex)
            var targetIndex = items.indexOf(text)
            if (targetIndex == -1) targetIndex = items.size
            items.add(targetIndex, source)
            ClipboardStore.reorder(this, items)
            clipboardMoveSource = null
            refreshClipboardStrip()
            return
        }
        currentInputConnection?.commitText(text, 1)
        closeClipboardStrip()
    }

    private fun openClipboardStrip() {
        refreshClipboardStrip()
        clipboardStripScroll.visibility = View.VISIBLE
        isClipboardOpen = true
    }

    private fun closeClipboardStrip() {
        if (!::clipboardStripScroll.isInitialized) return
        clipboardStripScroll.visibility = View.GONE
        isClipboardOpen = false
    }
}
