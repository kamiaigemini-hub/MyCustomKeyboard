package com.example.customkeyboard

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.customkeyboard.model.BackgroundType
import com.example.customkeyboard.model.GradientDirection
import com.example.customkeyboard.model.KeyboardTheme
import com.example.customkeyboard.model.LayoutStore
import com.example.customkeyboard.model.ThemeStore
import com.example.customkeyboard.view.KeyboardView

class ThemeActivity : AppCompatActivity() {

    private val presetColors = listOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFEDEFF2.toInt(), 0xFFD8DCE0.toInt(),
        0xFFFFC1CC.toInt(), 0xFFFF6B6B.toInt(), 0xFFFFA94D.toInt(), 0xFFFFD43B.toInt(),
        0xFF69DB7C.toInt(), 0xFF38D9A9.toInt(), 0xFF4C7CF0.toInt(), 0xFF748FFC.toInt(),
        0xFFB197FC.toInt(), 0xFFE599F7.toInt(), 0xFFF783AC.toInt(), 0xFF868E96.toInt()
    )

    private lateinit var theme: KeyboardTheme
    private lateinit var previewView: KeyboardView
    private lateinit var optionsContainer: LinearLayout
    private lateinit var sizeLabel: TextView

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // 일부 소스는 지속 권한을 지원하지 않을 수 있어요. 그래도 일단 시도합니다.
            }
            theme.backgroundImageUri = uri.toString()
            theme.backgroundType = BackgroundType.IMAGE
            applyAndRefresh()
        }
    }

    private val pickFontLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // 일부 소스는 지속 권한을 지원하지 않을 수 있어요. 그래도 일단 시도합니다.
            }
            theme.customFontUri = uri.toString()
            theme.fontFamily = "CUSTOM"
            applyAndRefresh()
            renderOptions()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        theme = ThemeStore.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "키보드 꾸미기"
            textSize = 20f
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)

        previewView = KeyboardView(this)
        root.addView(previewView)

        optionsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 24, 0, 0)
        }
        root.addView(optionsContainer)

        setContentView(ScrollView(this).apply { addView(root) })
        loadPreviewSampleLayout()
        renderOptions()
        applyAndRefresh()
    }

    private fun loadPreviewSampleLayout() {
        previewView.setLayout(LayoutStore.loadLayout(this, "en"))
    }

    private fun applyAndRefresh() {
        previewView.applyTheme(theme)
    }

    private fun renderOptions() {
        optionsContainer.removeAllViews()

        // 배경 종류
        optionsContainer.addView(sectionTitle("배경"))
        val bgTypeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bgTypeRow.addView(Button(this).apply {
            text = if (theme.backgroundType == BackgroundType.SOLID) "▶ 단색" else "단색"
            setOnClickListener { theme.backgroundType = BackgroundType.SOLID; applyAndRefresh(); renderOptions() }
        })
        bgTypeRow.addView(Button(this).apply {
            text = if (theme.backgroundType == BackgroundType.GRADIENT) "▶ 그라데이션" else "그라데이션"
            setOnClickListener { theme.backgroundType = BackgroundType.GRADIENT; applyAndRefresh(); renderOptions() }
        })
        bgTypeRow.addView(Button(this).apply {
            text = if (theme.backgroundType == BackgroundType.IMAGE) "▶ 이미지" else "이미지"
            setOnClickListener {
                theme.backgroundType = BackgroundType.IMAGE
                pickImageLauncher.launch(arrayOf("image/*"))
            }
        })
        optionsContainer.addView(bgTypeRow)

        when (theme.backgroundType) {
            BackgroundType.SOLID -> {
                optionsContainer.addView(colorSwatchButton("배경색 고르기", theme.backgroundColor) { picked ->
                    theme.backgroundColor = picked
                    applyAndRefresh()
                })
            }
            BackgroundType.GRADIENT -> {
                theme.gradientColors.forEachIndexed { idx, color ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    row.addView(colorSwatchButton("색 ${idx + 1}", color) { picked ->
                        val newColors = theme.gradientColors.toMutableList()
                        newColors[idx] = picked
                        theme.gradientColors = newColors
                        applyAndRefresh()
                    })
                    if (theme.gradientColors.size > 2) {
                        row.addView(Button(this).apply {
                            text = "삭제"
                            setOnClickListener {
                                val newColors = theme.gradientColors.toMutableList()
                                newColors.removeAt(idx)
                                theme.gradientColors = newColors
                                applyAndRefresh()
                                renderOptions()
                            }
                        })
                    }
                    optionsContainer.addView(row)
                }
                optionsContainer.addView(Button(this).apply {
                    text = "+ 색 추가"
                    setOnClickListener {
                        val newColors = theme.gradientColors.toMutableList()
                        newColors.add(Color.WHITE)
                        theme.gradientColors = newColors
                        applyAndRefresh()
                        renderOptions()
                    }
                })
                optionsContainer.addView(directionPicker(theme.gradientDirection) { picked ->
                    theme.gradientDirection = picked
                    applyAndRefresh()
                    renderOptions()
                })
            }
            BackgroundType.IMAGE -> {
                optionsContainer.addView(Button(this).apply {
                    text = "이미지 다시 고르기"
                    setOnClickListener { pickImageLauncher.launch(arrayOf("image/*")) }
                })
            }
        }

        // 버튼 색
        optionsContainer.addView(sectionTitle("버튼 색"))
        optionsContainer.addView(colorSwatchButton("일반 키 색", theme.keyColor) { picked ->
            theme.keyColor = picked
            applyAndRefresh()
        })
        optionsContainer.addView(colorSwatchButton("기능 키 색 (스페이스, 엔터 등)", theme.specialKeyColor) { picked ->
            theme.specialKeyColor = picked
            applyAndRefresh()
        })
        optionsContainer.addView(colorSwatchButton("글자 색", theme.textColor) { picked ->
            theme.textColor = picked
            applyAndRefresh()
        })

        // 글꼴
        optionsContainer.addView(sectionTitle("글꼴"))
        val fontRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontRow1.addView(Button(this).apply {
            text = if (theme.fontFamily == "DEFAULT") "▶ 기본" else "기본"
            setOnClickListener { theme.fontFamily = "DEFAULT"; applyAndRefresh(); renderOptions() }
        })
        fontRow1.addView(Button(this).apply {
            text = if (theme.fontFamily == "SANS_SERIF") "▶ 고딕체" else "고딕체"
            setOnClickListener { theme.fontFamily = "SANS_SERIF"; applyAndRefresh(); renderOptions() }
        })
        optionsContainer.addView(fontRow1)
        val fontRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontRow2.addView(Button(this).apply {
            text = if (theme.fontFamily == "SERIF") "▶ 명조체" else "명조체"
            setOnClickListener { theme.fontFamily = "SERIF"; applyAndRefresh(); renderOptions() }
        })
        fontRow2.addView(Button(this).apply {
            text = if (theme.fontFamily == "MONOSPACE") "▶ 고정폭" else "고정폭"
            setOnClickListener { theme.fontFamily = "MONOSPACE"; applyAndRefresh(); renderOptions() }
        })
        optionsContainer.addView(fontRow2)
        optionsContainer.addView(Button(this).apply {
            text = if (theme.fontFamily == "CUSTOM") "▶ 내 폰트 파일 사용 중 (다시 고르기)" else "내 폰트 파일 선택 (.ttf, .otf)"
            setOnClickListener { pickFontLauncher.launch(arrayOf("*/*")) }
        })

        // 키보드 크기
        optionsContainer.addView(sectionTitle("키보드 크기"))
        sizeLabel = TextView(this).apply { text = "${(theme.keySizeScale * 100).toInt()}%" }
        optionsContainer.addView(sizeLabel)
        val sizeSeek = SeekBar(this).apply {
            max = 70 // 70~140% 범위 (progress 0~70 -> 70~140)
            progress = ((theme.keySizeScale * 100).toInt() - 70).coerceIn(0, 70)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    theme.keySizeScale = (70 + progress) / 100f
                    sizeLabel.text = "${(theme.keySizeScale * 100).toInt()}%"
                    applyAndRefresh()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        optionsContainer.addView(sizeSeek)

        // 키 사이 간격
        optionsContainer.addView(sectionTitle("키 사이 간격"))
        val gapLabel = TextView(this).apply { text = "${(theme.keyGapScale * 100).toInt()}%" }
        optionsContainer.addView(gapLabel)
        val gapSeek = SeekBar(this).apply {
            max = 300 // 0~300% 범위
            progress = (theme.keyGapScale * 100).toInt().coerceIn(0, 300)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    theme.keyGapScale = progress / 100f
                    gapLabel.text = "${progress}%"
                    applyAndRefresh()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        optionsContainer.addView(gapSeek)

        // 테두리
        optionsContainer.addView(sectionTitle("키보드 테두리"))
        optionsContainer.addView(Button(this).apply {
            text = if (theme.borderEnabled) "▶ 테두리 켜짐" else "테두리 꺼짐 (탭해서 켜기)"
            setOnClickListener {
                theme.borderEnabled = !theme.borderEnabled
                applyAndRefresh()
                renderOptions()
            }
        })
        if (theme.borderEnabled) {
            val borderTypeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            borderTypeRow.addView(Button(this).apply {
                text = if (theme.borderType == BackgroundType.SOLID) "▶ 단색" else "단색"
                setOnClickListener { theme.borderType = BackgroundType.SOLID; applyAndRefresh(); renderOptions() }
            })
            borderTypeRow.addView(Button(this).apply {
                text = if (theme.borderType == BackgroundType.GRADIENT) "▶ 그라데이션" else "그라데이션"
                setOnClickListener { theme.borderType = BackgroundType.GRADIENT; applyAndRefresh(); renderOptions() }
            })
            optionsContainer.addView(borderTypeRow)

            if (theme.borderType == BackgroundType.SOLID) {
                optionsContainer.addView(colorSwatchButton("테두리 색 고르기", theme.borderColor) { picked ->
                    theme.borderColor = picked
                    applyAndRefresh()
                })
            } else {
                theme.borderGradientColors.forEachIndexed { idx, color ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    row.addView(colorSwatchButton("테두리 색 ${idx + 1}", color) { picked ->
                        val newColors = theme.borderGradientColors.toMutableList()
                        newColors[idx] = picked
                        theme.borderGradientColors = newColors
                        applyAndRefresh()
                    })
                    if (theme.borderGradientColors.size > 2) {
                        row.addView(Button(this).apply {
                            text = "삭제"
                            setOnClickListener {
                                val newColors = theme.borderGradientColors.toMutableList()
                                newColors.removeAt(idx)
                                theme.borderGradientColors = newColors
                                applyAndRefresh()
                                renderOptions()
                            }
                        })
                    }
                    optionsContainer.addView(row)
                }
                optionsContainer.addView(Button(this).apply {
                    text = "+ 색 추가"
                    setOnClickListener {
                        val newColors = theme.borderGradientColors.toMutableList()
                        newColors.add(Color.WHITE)
                        theme.borderGradientColors = newColors
                        applyAndRefresh()
                        renderOptions()
                    }
                })
                optionsContainer.addView(directionPicker(theme.borderGradientDirection) { picked ->
                    theme.borderGradientDirection = picked
                    applyAndRefresh()
                    renderOptions()
                })
            }

            val borderWidthLabel = TextView(this).apply { text = "두께: ${theme.borderWidth.toInt()}" }
            optionsContainer.addView(borderWidthLabel)
            optionsContainer.addView(SeekBar(this).apply {
                max = 40
                progress = theme.borderWidth.toInt().coerceIn(0, 40)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        theme.borderWidth = progress.toFloat()
                        borderWidthLabel.text = "두께: $progress"
                        applyAndRefresh()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            })
        }

        // 키 하나하나의 테두리
        optionsContainer.addView(sectionTitle("키 테두리"))
        optionsContainer.addView(Button(this).apply {
            text = if (theme.keyBorderEnabled) "▶ 키 테두리 켜짐" else "키 테두리 꺼짐 (탭해서 켜기)"
            setOnClickListener {
                theme.keyBorderEnabled = !theme.keyBorderEnabled
                applyAndRefresh()
                renderOptions()
            }
        })
        if (theme.keyBorderEnabled) {
            val keyBorderTypeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            keyBorderTypeRow.addView(Button(this).apply {
                text = if (theme.keyBorderType == BackgroundType.SOLID) "▶ 단색" else "단색"
                setOnClickListener { theme.keyBorderType = BackgroundType.SOLID; applyAndRefresh(); renderOptions() }
            })
            keyBorderTypeRow.addView(Button(this).apply {
                text = if (theme.keyBorderType == BackgroundType.GRADIENT) "▶ 그라데이션" else "그라데이션"
                setOnClickListener { theme.keyBorderType = BackgroundType.GRADIENT; applyAndRefresh(); renderOptions() }
            })
            optionsContainer.addView(keyBorderTypeRow)

            if (theme.keyBorderType == BackgroundType.SOLID) {
                optionsContainer.addView(colorSwatchButton("키 테두리 색 고르기", theme.keyBorderColor) { picked ->
                    theme.keyBorderColor = picked
                    applyAndRefresh()
                })
            } else {
                theme.keyBorderGradientColors.forEachIndexed { idx, color ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    row.addView(colorSwatchButton("키 테두리 색 ${idx + 1}", color) { picked ->
                        val newColors = theme.keyBorderGradientColors.toMutableList()
                        newColors[idx] = picked
                        theme.keyBorderGradientColors = newColors
                        applyAndRefresh()
                    })
                    if (theme.keyBorderGradientColors.size > 2) {
                        row.addView(Button(this).apply {
                            text = "삭제"
                            setOnClickListener {
                                val newColors = theme.keyBorderGradientColors.toMutableList()
                                newColors.removeAt(idx)
                                theme.keyBorderGradientColors = newColors
                                applyAndRefresh()
                                renderOptions()
                            }
                        })
                    }
                    optionsContainer.addView(row)
                }
                optionsContainer.addView(Button(this).apply {
                    text = "+ 색 추가"
                    setOnClickListener {
                        val newColors = theme.keyBorderGradientColors.toMutableList()
                        newColors.add(Color.WHITE)
                        theme.keyBorderGradientColors = newColors
                        applyAndRefresh()
                        renderOptions()
                    }
                })
                optionsContainer.addView(directionPicker(theme.keyBorderGradientDirection) { picked ->
                    theme.keyBorderGradientDirection = picked
                    applyAndRefresh()
                    renderOptions()
                })
            }

            val keyBorderWidthLabel = TextView(this).apply { text = "두께: ${theme.keyBorderWidth.toInt()}" }
            optionsContainer.addView(keyBorderWidthLabel)
            optionsContainer.addView(SeekBar(this).apply {
                max = 20
                progress = theme.keyBorderWidth.toInt().coerceIn(0, 20)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        theme.keyBorderWidth = progress.toFloat()
                        keyBorderWidthLabel.text = "두께: $progress"
                        applyAndRefresh()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            })
        }

        // 저장 / 초기화
        val buttonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 32, 0, 0)
        }
        buttonBar.addView(Button(this).apply {
            text = "저장"
            setOnClickListener {
                ThemeStore.save(this@ThemeActivity, theme)
                Toast.makeText(this@ThemeActivity, "저장되었습니다", Toast.LENGTH_SHORT).show()
            }
        })
        buttonBar.addView(Button(this).apply {
            text = "기본값으로 재설정"
            setOnClickListener {
                ThemeStore.reset(this@ThemeActivity)
                theme = ThemeStore.load(this@ThemeActivity)
                applyAndRefresh()
                renderOptions()
            }
        })
        optionsContainer.addView(buttonBar)
    }

    private fun directionPicker(current: GradientDirection, onPicked: (GradientDirection) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val options = listOf(
            GradientDirection.TOP_TO_BOTTOM to "위→아래",
            GradientDirection.LEFT_TO_RIGHT to "왼쪽→오른쪽",
            GradientDirection.DIAGONAL to "대각선",
            GradientDirection.RADIAL to "원형"
        )
        options.forEach { (dir, label) ->
            row.addView(Button(this).apply {
                text = if (dir == current) "▶ $label" else label
                setOnClickListener { onPicked(dir) }
            })
        }
        return row
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(0, 24, 0, 8)
    }

    /** 색상 이름 + 지금 고른 색을 보여주는 버튼. 누르면 프리셋/직접입력 다이얼로그가 열립니다. */
    private fun colorSwatchButton(label: String, current: Int, onPicked: (Int) -> Unit): Button {
        return Button(this).apply {
            text = label
            setOnClickListener { showColorPickerDialog(current, onPicked) }
        }
    }

    private fun showColorPickerDialog(current: Int, onPicked: (Int) -> Unit) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 16)
        }

        val dialogHolder = arrayOfNulls<AlertDialog>(1)
        var row: LinearLayout? = null
        presetColors.forEachIndexed { i, color ->
            if (i % 4 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                container.addView(row)
            }
            val swatch = Button(this).apply {
                text = ""
                setBackgroundColor(color)
                layoutParams = LinearLayout.LayoutParams(120, 120).apply { setMargins(8, 8, 8, 8) }
                setOnClickListener {
                    onPicked(color)
                    dialogHolder[0]?.dismiss()
                }
            }
            row?.addView(swatch)
        }

        val hexHint = TextView(this).apply {
            text = "또는 직접 색상 코드 입력 (예: #FF8800)"
            setPadding(0, 24, 0, 8)
        }
        container.addView(hexHint)
        val hexInput = EditText(this).apply {
            hint = "#RRGGBB"
            gravity = Gravity.START
        }
        container.addView(hexInput)

        val dialog = AlertDialog.Builder(this)
            .setTitle("색 고르기")
            .setView(container)
            .setPositiveButton("적용") { _, _ ->
                val text = hexInput.text.toString().trim()
                if (text.isNotEmpty()) {
                    try {
                        val hex = if (text.startsWith("#")) text else "#$text"
                        onPicked(Color.parseColor(hex))
                    } catch (e: Exception) {
                        Toast.makeText(this, "색상 코드를 확인해주세요 (예: #FF8800)", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("취소", null)
            .create()
        dialogHolder[0] = dialog
        dialog.show()
    }
}
